<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}
get_header();
?>
<?php 
global $wpdb;
do_action('bmp_check_downline_validate');
$downlines=new BMP_Genealogy();
$downlines->downlinesFunction();
?>
<?php
get_footer();
?>