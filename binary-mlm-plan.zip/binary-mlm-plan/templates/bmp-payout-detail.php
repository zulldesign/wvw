<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}
get_header();
?>
<?php 

do_action('bmp_user_check_payout');
do_action('bmp_user_payout_detail');
do_action('bmp_user_payout_bonus_details');
?>
<?php
get_footer();
?>