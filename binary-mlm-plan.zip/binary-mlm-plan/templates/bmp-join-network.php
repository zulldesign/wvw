<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}
get_header();
?>
<?php 
do_action('bmp_join_network');
?>
<?php
get_footer();
?>