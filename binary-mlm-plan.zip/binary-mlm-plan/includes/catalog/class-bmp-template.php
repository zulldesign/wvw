<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

add_filter( 'page_template', 'bmp_page_template',10,2);
function bmp_page_template( $page_template,$temp)
{
	global $post;
	  	
  	if (is_page('join-network') && get_option('bmp_join_network_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
  			add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
  			$page_template = BMP_ABSPATH . '/templates/bmp-join-network.php';
		}
	if (is_page('register') && get_option('bmp_register_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
  			add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
  			$page_template = BMP_ABSPATH . '/templates/bmp-register.php';
		}

	if (is_page('downlines') && get_option('bmp_downlines_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
				add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
				$page_template = BMP_ABSPATH . '/templates/bmp-downlines.php';
		}
	if (is_page('bmp-account-detail') && get_option('bmp_bmp-acccount-detail_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
				add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
				$page_template = BMP_ABSPATH . '/templates/bmp-account-detail.php';
		}
	if (is_page('bmp-payout-detail') && get_option('bmp_bmp_payout_detail_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
				add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
				$page_template = BMP_ABSPATH . '/templates/bmp-payout-detail.php';
		}
	if (is_page('bmp-auto-add') && get_option('bmp_bmp_auto_add_page_id',true)==$post->ID && get_post_meta($post->ID,'is_bmp_page',true)==1) { 
			add_action( 'wp_enqueue_scripts', 'custom_bmp_style' );
			$page_template = BMP_ABSPATH . '/templates/bmp-auto-add.php';
	}

    return $page_template;
}


function custom_bmp_style() {
	
	if (is_page('join-network') ||is_page('register') || is_page('downlines')  || is_page('bmp-account-detail')  || is_page('bmp-payout-detail') || is_page('bmp-auto-add')) {
		wp_enqueue_script('jquery');
		wp_enqueue_style( 'bmp_bootstrap', BMP()->plugin_url() . '/assets/css/bootstrap.min.css' );
		wp_enqueue_style( 'bmp_main', BMP()->plugin_url() . '/assets/css/bmp.css' );
		wp_enqueue_script( 'bmp_main', BMP()->plugin_url() . '/assets/js/main.js', array(), '', true);
	}
}
