<div class="content_style">
<div class="form-row">
	<div class="col-md-12"><h4><?php _e('Payout Distribution','bmp');?></h4></div><br>						
	
	<div class="col-md-12">
		<div class="form-group  bmp-section ml-1">
		<?php _e('The Bonus Commission Distribution can be show when you will process for the Bonus commision. there are some Restriction to show the commission before run the Bonus commission. So kindly run first of all bonus commission then you find how much bonus commission you got now. Another Restriction is that, only one time the commission will be display. if you will run again then it will not show because commission has been distributed already when you run first time the bonus commission distribution.','bmp');?>								
		</div>
	</div>	
	<?php 
		if($_POST){
			$dataarray=bmp_run_payout_functions();
		} else{
			$dataarray=bmp_run_payout_display_functions();
			//echo '<pre>';print_r($dataarray);echo '</pre>'; die;

		}
	?>
	
	  <div class="table-responsive">      
	  <table class="table-bordered table ml-1  table-striped">
	    <thead>
	      <tr>
	        <th>#</th>
	        <th><?php _e('User Name','bmp');?></th>
	        <th><?php _e('First Name','bmp');?></th>
	        <th><?php _e('Last Name','bmp');?></th>
	        <th><?php _e('Commission','bmp');?></th>
	        <th><?php _e('Direct Refferal Commission','bmp');?></th>
	        <th><?php _e('Bonus Commission','bmp');?></th>
	        <th><?php _e('Total Amount','bmp');?></th>
	        <th><?php _e('Cap Limit','bmp');?></th>
	        
	        <th><?php _e('Tax','bmp');?></th>
	        <th><?php _e('Service Charge','bmp');?></th>
	        <th><?php _e('Net Amount','bmp');?></th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php 
	    	if($dataarray){
	    	foreach($dataarray as $key=>$row){ ?>
	      <tr>
	        <td><?php echo ++$key;?></td>
	        <td><?php echo $row['username'];?></td>
	        <td><?php echo $row['first_name'];?></td>
	        <td><?php echo $row['last_name'];?></td>
	        <td><?php echo $row['commission'];?></td>
	        <td><?php echo $row['direct_refferal_commission'];?></td>
	        <td><?php echo $row['bonus'];?></td>
	        <td><?php echo $row['total_amount'];?></td>
	        <td><?php echo $row['cap_limit'];?></td>
	        
	        <td><?php echo $row['tax'];?></td>
	        <td><?php echo $row['service_charge'];?></td>
	        <td><?php echo $row['net_amount'];?></td>
	      </tr>
	      <?php 
	  		} 
	      } else { 
	      	if(sanitize_text_field($_POST)){
	      ?>
	      <tr>
	        <td colspan="12"><?php echo __('Payout Run successfully','bmp');?></td>
	      </tr>
	  <?php } else {?>
	  	<tr>
	        <td colspan="12"><?php echo __('No Record is here. Please click on Commission Distribute Button. If yet No Record Get , Its Mean you have not commission to distribute.','bmp');?></td>
	      </tr>
	      <?php } ?>
	  <?php } ?>
	    </tbody>
	  </table>
	</div>
</div>
</div>