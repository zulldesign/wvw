<?php 
global $wpdb;
$currencies=$this->getCurrency();
$settings=get_option('bmp_manage_general');
$epings=$this->getepinlength();
//echo '<pre>';print_r($settings);echo '</pre>';
?>

<div class="form-row">
	<div class="col-md-12"><h2><?php _e('Generel Settings','bmp');?></h2></div>
	<br>						
	<div class="col-md-12" style="float:left;">
	<table class="form-table">	
	<tbody>
	<th scope="row"><label for="default_role" title="Select your currency which will you use.!"><?php _e('Currency','bmp');?></label></th>	
	<td>
   <select name="bmp_personal_referrer" id="bmp_personal_referrer" required=""
	placeholder="" required="">
		<?php foreach($currencies as $key=>$value){?>
			<option value="<?php echo $key;?>" <?php echo (!empty($settings['bmp_personal_referrer']) && $settings['bmp_personal_referrer']==$key)?'selected':'';?>><?php echo $value;?></option>
		<?php } ?>
   </select>
	<small id="bmp_personal_referrerHelp" class="form-text text-muted"><?php _e('Select your currency which will you use.','bmp');?></small>
  </td>
  </tr>
  </tbody>
  </table>				
		
	</div>

	
	<div class="col-md-12" style="float:left;">
		<table class="form-table">

<tbody><tr>
<th scope="row"><label for="bmp_affiliate_url"><?php _e('Redirect Affiliate URL:','bmp');?> <?php echo get_site_url();?></label></th>
<td><input name="bmp_affiliate_url" id="bmp_affiliate_url" type="text" style="" value="<?php echo !empty($settings['bmp_affiliate_url'])?$settings['bmp_affiliate_url']:'';?>" required class="regular-text" ></td>
	<small id="bmp_affiliate_urlHelp" class="form-text text-muted"></small>
</tr>
</tbody>
</table>
		
	</div>
	
	
	<div class="col-md-12" style="float:left;">
		<table class="form-table">
	<tbody>
	 <tr>
   <th scope="row"><?php _e('Use WP registration page','bmp');?> </th>
   <td> <fieldset><legend class="screen-reader-text"><span><?php _e('Use WP registration page','bmp');?> </span></legend><label for="users_can_register">
  <input type="checkbox" id="bmp_wp_register-1" name="bmp_wp_register" value="1" class="" style="" <?php echo (isset($settings['bmp_wp_register'])==1)?'checked':'';?>> &nbsp;<?php _e('register Using WP Register','bmp');?></label>
   </fieldset></td>
   </tr>
   </tbody>
	</table>
	</div>
	
	
	<div class="col-md-12" style="float:left;">
		<table class="form-table">

<tbody><tr>
<th scope="row"><label for="bmp_register_url"><?php _e('URL of registration page:','bmp');?> <?php echo get_site_url();?></label></th>
<td><input name="bmp_register_url" id="bmp_register_url" type="text" style="" value="<?php echo !empty($settings['bmp_register_url'])?$settings['bmp_register_url']:'';?>" required class="regular-text" ></td>
	<small id="bmp_register_url_help" class="form-text text-muted"></small>
</tr>
</tbody>
</table>
	</div>

	<div class="col-md-12" style="float:left;">
		<table class="form-table">

<tbody><tr>
<th scope="row"><?php _e('Activate ePin','bmp');?></th>
<td>
	<fieldset><legend class="screen-reader-text"><span><?php _e('Activate ePin','bmp');?></span></legend>
	<label><input type="radio" id="bmp_ePin_activate-1" name="bmp_epin_activate" value="1" class=" " style="" <?php echo (!empty($settings['bmp_epin_activate']) && $settings['bmp_epin_activate']==1)?'checked':'';?> required="" placeholder=""><?php _e('Yes','bmp');?></label><br>

	<label><input type="radio" id="bmp_ePin_activate-0" name="bmp_epin_activate" value="0" class=" " style="" required="" placeholder="" <?php echo (!empty($settings['bmp_epin_activate']) && $settings['bmp_epin_activate']==0)?'checked':'';?>><?php _e('No','bmp');?></label><br>
	
</fieldset>
</td>
</tr>
</tbody>
</table>
	</div>

<!--<div class="col-md-12" style="float:left;">
	<table class="form-table">
	<tbody>
	<tr>
	<th scope="row"><?php _e('Activate Royalty Bonus','bmp');?></th>
	<td>
		<fieldset><legend class="screen-reader-text"><span><?php _e('Activate Royalty Bonus','bmp');?></span></legend>
		<label><input type="radio"  id="bmp_royalty_activate-1" name="bmp_royalty_activate" value="1" class=" " style="" <?php echo (!empty($settings['bmp_royalty_activate']) && $settings['bmp_royalty_activate']==1)?'checked':'';?> required="" placeholder=""><?php _e('Yes','bmp');?></label><br>

		<label><input type="radio" id="bmp_royalty_activate-0" name="bmp_royalty_activate" value="0" class=" " style="" required="" placeholder="" <?php echo (!empty($settings['bmp_royalty_activate']) && $settings['bmp_royalty_activate']==0)?'checked':'';?>><?php _e('No','bmp');?></label><br>
			<small id="bmp_royalty_activateHelp" class="form-text text-muted">	
			</small>
	</fieldset>
	</td>
	</tr>
	</tbody>
	</table>
</div>-->

	<div class="col-md-12" style="float:left;">
	<table class="form-table">	
	<tbody>
	<th scope="row"><label for="default_role" title="Select your currency which will you use.!"><?php _e('ePin Length','bmp');?></label></th>	
	<td>
   <select name="bmp_epin_length" id="bmp_epin_length" required=""
	placeholder="" required="">
		<?php foreach($epings as $epin){?>
			<option value="<?php echo $epin;?>" <?php echo (!empty($settings['bmp_epin_length']) && $settings['bmp_epin_length']==$epin)?'selected':'';?>><?php echo $epin;?></option>
			<?php } ?>
		</select>
	<small id="bmp_epin_lengthHelp" class="form-text text-muted"><?php _e('Select Your ePin Length','bmp');?></small>
  </td>
  </tr>
  </tbody>
  </table>				
	</div>

<div class="col-md-12" style="float:left;">
		<table class="form-table">

<tbody><tr>
<th scope="row"><?php _e('Product Price','bmp');?></th>
<td>
	<fieldset><legend class="screen-reader-text" title="!"><span><?php _e('Product Price','bmp');?></span></legend>
	<label><input type="radio" id="bmp_product_price-1" name="bmp_product_price" value="1" class=" " style="" <?php echo (!empty($settings['bmp_product_price']) && $settings['bmp_product_price']==1)?'checked':'';?> required="" placeholder=""><?php _e('Yes','bmp');?></label><br>

	<label><input type="radio" id="bmp_product_price-0" name="bmp_product_price" value="0" class=" " style="" required="" placeholder="" <?php echo (!empty($settings['bmp_product_price']) && $settings['bmp_product_price']==0)?'checked':'';?>><?php _e('No','bmp');?></label><br>
		<small id="bmp_product_priceHelp" class="form-text text-muted">	</small>
</fieldset>
</td>
</tr>
</tbody>
</table>
	</div>
								
 <!--<div class="col-md-12" style="float:left;">
  <table class="form-table">
<tbody><tr>
<th scope="row"><?php _e('Process Withdrawals','bmp');?></th>
<td>
	<fieldset><legend class="screen-reader-text" title="!"><span><?php _e('Process Withdrawals','bmp');?></span></legend>
	<label><input type="radio" id="bmp_process_withdrawal-automatically" name="bmp_process_withdrawal" value="automatically" class=" " style="" <?php echo ($settings['bmp_process_withdrawal']==1)?'checked':'';?> required="" placeholder="">
				  	 <?php _e('Automatically','bmp');?>	</label><br>

	<label><input type="radio"id="bmp_process_withdrawal-manually" name="bmp_process_withdrawal" value="manually" class=" " style="" required="" placeholder="" <?php echo ($settings['bmp_process_withdrawal']==0)?'checked':'';?>>
				  	 <?php _e('Manually','bmp');?></label><br>
		<small id="bmp_process_withdrawal_help" class="form-text text-muted">								
		</small>
</fieldset>
</td>
</tr>
</tbody>
</table>
	</div>	-->
	<script>$(document).ready(function(){
	if ($('#bmp_wp_register-1').is(':checked')) {
        $('#bmp_register_url').removeAttr('readonly');
    }
    $('#bmp_wp_register-1').click(function(){

    	if ($(this).is(':checked')) {
        	$('#bmp_register_url').removeAttr('readonly');
    	} else {
    		$('#bmp_register_url').attr('readonly', true);
    	}

   });
    
});
</script>
</div>
