<div class="form-row">
	<?php 
	global $wpdb;
	$row_num=0;
	$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}bmp_product_price", OBJECT );
	
	?>
	<div class="col-md-12"><h2><?php _e('ePin Settings','bmp');?></h2></div><br>	

	<div id="epin_typw" class="col-md-12" style="float:left;">
		<div class="form-group ">
	    <table class="form-table">
        <tbody>
         <tr>
         	<th scope="row"><label for=""><?php _e('ePin Type','bmp');?></label></th>
         	<td>
         	<select name="bmp_epin_type" id="bmp_epin_type" class="form-control"  required>
				<option value=""><?php _e('Select ePin Type','bmp');?></option>
				<option value="regular"><?php _e('Regular','bmp');?></option>
				<option value="free"><?php _e('Free','bmp');?></option>
		    </select>
			</td>
		  </tr>
	     </tbody>
        </table>
		</div>
	  </div>

	  <div id="epin_product" class="col-md-12" style="float:left;">
		<div class="form-group ">
	    <table class="form-table">
        <tbody>
         <tr>
         	<th scope="row"><label for=""><?php _e('ePin Product','bmp');?></label></th>
         	<td>
         <select name="bmp_epin_product" id="bmp_epin_product" class="form-control"  required>
				<option value=""><?php _e('Select ePin Product','bmp');?></option>
				<?php foreach($results as $result){?>
					<option value="<?php echo $result->id;?>"><?php echo $result->name;?></option>
				<?php } ?>
		</select>		
			</td>
		  </tr>
	     </tbody>
        </table>
		</div>
	  </div>

	    <div id="epin_number" class="col-md-12" style="float:left;">
		<div class="form-group ">
	    <table class="form-table">
        <tbody>
         <tr>
         	<th scope="row"><label for=""><?php _e('Number Of ePins','bmp');?> </label></th>
         	<td>
        <input name="bmp_epin_number" id="bmp_epin_number" class="form-control" required>				
			</td>
		  </tr>
	     </tbody>
        </table>
		</div>
	  </div>
</div>