<?php
/**
 * UMW General Settings
 *
 * @package UMW/Admin
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

if ( class_exists( 'BMP_Settings_General', false ) ) {
	return new BMP_Settings_General();
}

/**
 * BMP_Admin_Settings_General.
 */
class BMP_Settings_General extends BMP_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() { 
		$this->id    = 'setting';
		$this->label = __( 'Setting', 'bmp' );

		parent::__construct();

		add_action( 'bmp_settings_save_' . $this->id, array( $this, 'save' ) );
		add_action( 'bmp_sections_' . $this->id, array( $this, 'output_sections' ) );
		add_action( 'bmp_settings_' . $this->id, array( $this, 'output' ) );
		
	}


	public function get_sections() {
		global $wpdb;

		$general_settings=get_option('bmp_manage_general');
		$sections = array();

		$user_count=$this->bmpUserCount();
		
		if($user_count<1){
			$sections['first_user']=__('First User', 'bmp');
		}

		$sections['general']=__('General', 'bmp');
		$sections['eligibility']=__('Eligibility', 'bmp');
		$sections['payout']=__('Payout', 'bmp');
		$sections['bonus']=__('Bonus', 'bmp');
		//$sections['email']=__('Email', 'bmp');

		$sections['manage_product']=__('Manage Product', 'bmp');

		$bmp_epin_activate=!empty($general_settings['bmp_epin_activate'])?$general_settings['bmp_epin_activate']:'';
		$bmp_royalty_activate=!empty($general_settings['bmp_royalty_activate'])?$general_settings['bmp_royalty_activate']:'';

		if($bmp_epin_activate){
			$sections['epin'] =__('ePins', 'bmp');
		}

	return apply_filters( 'bmp_get_sections_' . $this->id, $sections );
}

public function output_sections() {
	global $current_section;

	$sections = $this->get_sections();

	if ( empty( $sections ) || 1 === sizeof( $sections ) ) {
		return;
	}

	echo '<div class="wrap_style"><ul>';

	$array_keys = array_keys( $sections );

	foreach ( $sections as $id => $label ) {
		echo '<li class="list_style"><a href="' . admin_url( 'admin.php?page=bmp-settings&tab=' . $this->id . '&section=' . sanitize_title( $id ) ) . '" class="' . ( $current_section == $id ? 'current' : '' ) . '">' . $label . '</a> </li>';
	}

	echo '</ul></div>';
}



	/**
	 * Get settings array.
	 *
	 * @return array
	 */
	public function get_settings($current_section = '') {
		$settings = array();
		if ( '' === $current_section ) {
			
			$array_setings = include 'view/view_general_settings.php';
			$settings = apply_filters('bmp_general_settings',$array_setings);

		} elseif ( 'eligibility' === $current_section ) {
			$array_setings = include 'view/view_eligibility_settings.php';
			$settings = apply_filters('bmp_eligibility_settings', $array_setings);

		}  elseif ( 'payout' === $current_section ) {
			$array_setings = include 'view/view_payout_settings.php';
			$settings = apply_filters('bmp_payout_settings', $array_setings);

		 } 
		  elseif ( 'bonus' === $current_section ) { 
		 	$array_setings = include 'view/view_bonus_settings.php';
		 	$settings = apply_filters('bmp_ponus_settings', $array_setings);

		 }

		return apply_filters( 'bmp_get_settings_' . $this->id, $settings );
	}


	public function getepinlength()
	{
		return array('8'=>'8','9'=>'9','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14','15'=>'15');
	}

	public function output() {
		global $current_section;
		
		echo '<div class="content_style">';

		if($current_section=='bonus'){
			$this->bmpUserRedirect();
			include 'view/view_bonus_settings.php';
		} elseif($current_section=='email'){
			$this->bmpUserRedirect();
			include 'view/view_email_settings.php';
		} elseif($current_section=='manage_product'){
			$this->bmpUserRedirect();
			include 'view/view_product_price_settings.php';
		} elseif($current_section=='epin'){
			$this->bmpUserRedirect();
			include 'view/view_epin_settings.php';
		} elseif($current_section=='payout'){
			$this->bmpUserRedirect();
			include 'view/view_payout_settings.php';
		} elseif($current_section=='eligibility'){
			$this->bmpUserRedirect();
			include 'view/view_eligibility_settings.php';
		} elseif($current_section=='royalty'){
			$this->bmpUserRedirect();
			include 'view/view_royalty_settings.php';
		} elseif($current_section=='general'){
			$this->bmpUserRedirect();
			include 'view/view_general_settings.php';
		} elseif($current_section=='first_user'){

			$bmp_user_count=$this->bmpUserCount();
			if($bmp_user_count>0){
				wp_redirect(admin_url('admin.php?page=bmp-settings&tab=' . $this->id . '&section=general'));
				exit;
			}
			include 'view/view_first_user_settings.php';
		} else{
			$this->bmpUserRedirect();
			include 'view/view_general_settings.php';
		} 
		echo'</div>';
		
	}

	public function bmpUserRedirect()
	{
		$bmp_user_count=$this->bmpUserCount();
		if($bmp_user_count==0){
			wp_redirect(admin_url('admin.php?page=bmp-settings&tab=' . $this->id . '&section=first_user'));
			exit;
		}
	}

	/**
	 * Save settings.
	 */

	public function save() {
		global $current_section,$wpdb;
		global $wp_session;
		
		if ( ! $current_section ) {
			
			//BMP_Admin_Settings::save_fields($settings );
			$this->manageGeneral($_POST);
		} 
		
		if( $current_section ) {
			if($current_section=='bonus'){
				$this->manageBonus($_POST);
			} elseif($current_section=='email'){
					$this->updateEmailOption($_POST);
				
			} elseif($current_section=='manage_product'){
					
				$this->manageProduct($_POST);
			} elseif($current_section=='epin'){
					
				$this->manageEpins($_POST);
			} elseif($current_section=='payout'){
					
				$this->managePayout($_POST);
			} elseif($current_section=='eligibility'){
					
				$this->manageEligibility($_POST);
			} elseif($current_section=='royalty'){
					
				$this->manageRoyalty($_POST);
			} elseif($current_section=='general'){
					
				$this->manageGeneral($_POST);
			} elseif($current_section=='first_user'){
					
				$this->manageFirstUser($_POST);
			} else { 
					
				$this->manageGeneral($_POST);
			}			
			
		}
	}

	public function manageFirstUser($data){
		global $wpdb;
		global $wp_session;
		$flag=true;
		if($data['new_bmp_user']){
		if ( username_exists( $data['bmp_first_username'] ) ) {
			$wp_session['bmp_save_error'] = __('User Name Already Exist. Please try another user name.','bmp');
			BMP_Admin_Settings::add_error(__('User Name Already Exist. Please try another user name.','bmp'));
			$flag=false;
		}

		if ( email_exists( $data['bmp_first_email'] ) ) {
			$wp_session['bmp_save_error'] = __('User Email Alraedy Exists.Please use another email','bmp');
			BMP_Admin_Settings::add_error(__('User Email Alraedy Exists.Please use another email','bmp'));
			$flag=false;
		}

		if($data['bmp_first_password'] != $data['bmp_first_confirm_password']){
			$wp_session['bmp_save_error'] = __('Password Does not match','bmp');
			BMP_Admin_Settings::add_error(__('Password Does not match','bmp'));
			$flag=false;
		}

		if($flag){
			$userdata = array(
			    'user_login' =>  $data['bmp_first_username'],
			    'user_email' => $data['bmp_first_email'],
			    'user_pass'  =>  $data['bmp_first_password'] 
			);
			 
			$user_id = wp_insert_user( $userdata ) ;
			 
			// On success.
			if ( ! is_wp_error( $user_id ) ) {
				$bmp_user = new WP_User( $user_id );
        		$bmp_user->set_role( 'bmp_user' );
        		$user_key = bmp_generateKey();
        		$insert = "INSERT INTO {$wpdb->prefix}bmp_users (user_id, user_name, user_key, parent_key, sponsor_key, position,payment_status)
                          VALUES('".$user_id."','".$data['bmp_first_username']."', '".$user_key."', '0', '0', '0', '1')";
                $wpdb->query($insert);
                $wp_session['bmp_save_message'] = __('Binary MLM Plan User created successfully.','bmp');
                BMP_Admin_Settings::add_message(__('Binary MLM Plan User created successfully.','bmp'));
			}
		}
		} else { 
			$user_id=$data['bmp_existing_user'];
			$bmp_user = new WP_User( $user_id );
    		$bmp_user->set_role('bmp_user');
    		$user_key = bmp_generateKey();
    		$insert = "INSERT INTO {$wpdb->prefix}bmp_users (user_id, user_name, user_key, parent_key, sponsor_key, position)
                          VALUES('".$user_id."','".$bmp_user->user_login."', '".$user_key."', '0', '0', '0')";
            $wpdb->query($insert);
            $wp_session['bmp_save_message'] = __('Binary MLM Plan User created successfully.','bmp');
            BMP_Admin_Settings::add_message(__('Binary MLM Plan User created successfully.','bmp'));
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=general' ) );

	}

	public function bmpUserCount(){
		global $wpdb;
		
		return $wpdb->get_var("SELECT Count(*) FROM {$wpdb->prefix}bmp_users");
	}

	public function manageBonus($data){
		global $wp_session;
		update_option('bmp_bonus_criteria',$data['bmp_bonus_criteria']);
		update_option('bmp_bonus',$data['bmp_bonus']);
		$wp_session['bmp_save_message'] = __('Bonus Settings Has been save successfully.','bmp');

		BMP_Admin_Settings::add_message(__('Bonus Settings Has been save successfully.','bmp'));
		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=manage_product' ));
	}

	public function manageGeneral($data){
		global $wp_session;
		
		update_option('bmp_manage_general',$data);
		$wp_session['bmp_save_message'] = __('General Settings Has been save successfully.','bmp');
		BMP_Admin_Settings::add_message(__('General Settings Has been save successfully.','bmp'));

		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=eligibility' ));
	}

	public function manageEligibility($data)
	{
		global $wp_session;
		update_option('bmp_manage_eligibility',$data);

		$wp_session['bmp_save_message'] = __('Eligibility Settings Has been save successfully.','bmp');

		BMP_Admin_Settings::add_message(__('Eligibility Settings Has been save successfully.','bmp'));
		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=payout' ));
	}

	public function managePayout($data){
		global $wp_session;
		update_option('bmp_manage_payout',$data);
		$wp_session['bmp_save_message'] = __('Payout Settings Has been save successfully.','bmp');
		BMP_Admin_Settings::add_message(__('Payout Settings Has been save successfully.','bmp'));
		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=bonus' ));
	}

	public function manageEpins($data)
	{
		global $current_section,$wpdb;
		global $wp_session;
		$general_settings=get_option('bmp_manage_general',true);
		$bmp_ePin_activate=!empty($general_settings['bmp_ePin_activate'])?$general_settings['bmp_ePin_activate']:'';
		$bmp_epin_length=$general_settings['bmp_epin_length'];
		$bmp_epin_type=$data['bmp_epin_type'];
		$bmp_epin_product=$data['bmp_epin_product'];
		$bmp_epin_number=$data['bmp_epin_number'];

		for ($i = 0; $i <= $bmp_epin_number - 1; $i++) {
            $epin_no = bmp_epinGenarate($bmp_epin_length);
            do {
                $check = $wpdb->get_var("SELECT COUNT(*) ck FROM {$wpdb->prefix}bmp_epins WHERE `epin_no` = '" . $epin_no . "'");
                $flag = 1;
                if ($check == 1) {
                    $epin_no = bmp_epinGenarate($bmp_epin_length);
                    $flag = 0;
                }
            } while ($flag == 0);

            $query = "insert into {$wpdb->prefix}bmp_epins set epin_no='$epin_no',type='$bmp_epin_type',product_id='" . $bmp_epin_product . "', date_generated=now();";

            $wpdb->query($query);
            if ($i == $bmp_epin_length - 1) {
                $message = 1;
            }
            else {
                $message = 0;
            }
        }
        $wp_session['bmp_save_message'] = __('Epins has been save successfully.','bmp');
        BMP_Admin_Settings::add_message(__('Epins has been save successfully.','bmp'));
		
	}

	public function updateEmailOption($data){
		global $wp_session;
		update_option('bmp_manage_email',$data);

		$wp_session['bmp_save_message'] = __('Email Settings Has been save successfully.','bmp');
		BMP_Admin_Settings::add_message(__('Email Settings Has been save successfully.','bmp'));

	}


	public function manageRoyalty($data){
		global $current_section,$wpdb;
		global $wp_session;
		$wpdb->query("TRUNCATE TABLE {$wpdb->prefix}bmp_royalty");
		foreach($data['royalty_manage'] as $royalty_manage){

			if($royalty_manage['id']){
				$wpdb->query("UPDATE {$wpdb->prefix}bmp_royalty SET name='".$royalty_manage['name']."',pair_start='".$royalty_manage['pair_start']."',pair_end='".$royalty_manage['pair_end']."',pool_percentage='".$royalty_manage['pool_percentage']."',pool_cap='".$royalty_manage['pool_cap']."',added_date=NOW(),modified_date=NOW() WHERE id='".$royalty_manage['id']."'");
			} else{
			$wpdb->query("INSERT INTO {$wpdb->prefix}bmp_royalty SET name='".$royalty_manage['name']."',pair_start='".$royalty_manage['pair_start']."',pair_end='".$royalty_manage['pair_end']."',pool_percentage='".$royalty_manage['pool_percentage']."',pool_cap='".$royalty_manage['pool_cap']."',added_date=NOW(),modified_date=NOW()");
			}

		}
		$wp_session['bmp_save_message'] = __('Royalty Income Settings Has been save successfully.','bmp');
		BMP_Admin_Settings::add_message(__('Royalty Income Settings Has been save successfully.','bmp'));		
	}

	public function manageProduct($data){
		global $current_section,$wpdb;
		global $wp_session;

		if(!empty($data['product_manage'])){
		$wpdb->query("TRUNCATE TABLE {$wpdb->prefix}bmp_product_price");

		foreach($data['product_manage'] as $product_manage){

			$wpdb->query("INSERT INTO {$wpdb->prefix}bmp_product_price SET name='".$product_manage['name']."',amount='".$product_manage['amount']."'");
		}
		}
		$wp_session['bmp_save_message'] = __('Product Price Settings Has been save successfully.','bmp');
		BMP_Admin_Settings::add_message(__('Product Price Settings Has been save successfully.','bmp'));

		wp_safe_redirect( admin_url( 'admin.php?page=bmp-settings&tab=setting&section=epin' ));
	}

}

//return new BMP_Settings_General();
