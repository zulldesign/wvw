
<div class="wrap" id="profile-page">
<?php
do_action('bmp_admin_user_account_detail');
do_action('bmp_admin_user_downlines_list');
do_action('bmp_admin_user_payout_list');
?>
</div>