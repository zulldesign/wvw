=== Binary MLM Plan ===
Contributors: LetsCMS
Donate link: http://letscms.com/
Tags: binary network,Binary MLM,multi level marketing,MLM,Genealogy Plan
Requires at least: 4.0
Tested up to: 5.0
Stable tag: 4.9
Requires PHP: 5.5
License: GPLv2 or later

Binary MLM is a plug and play plugin which helps to manage binary networks within the WordPress CMS. A binary mlm plan is a binary structure used in multi-level marketing (MLM) organizations.

== Description ==

==Paid Service==
This plugin is free to use. If you need support then support charges will be $15/hour and customisation charges also $15/hour.

==What is Binary MLM Plan Software ?==
A binary mlm plan is a binary structure used in multi-level marketing (MLM) organizations. In this structure, new user are introduced into a system with a tree-like structure where each “node” or new user of the organization has a left and right sub-tree. each sub-tree of a binary mlm plan works like a tree.

===Features===

== Admin Features ==

1. Generate ePins (Regular and Free)
2. ePin Report (Used and UnUsed ePins)
3. Payout Reports
4. Report to show complete details of an individual payout
5. Affiliate Comission
6. Pair Commission
7. Bonus Commission
8. Admin access to mark a binary mlm user paid / unpaid
9. Specify base currency in the admin
10. Specify eligibility criteria in the admin
11. Configurartion of commission and bonus details in the admin
12. Service Charges for payout
13. Run payouts manually
14. Payout Detail based on user in admin

== Frontend Features ==

1. Register a Binary MLM User from provided registration page.
2. Register new Members using Genealogy
3. New Join Network Page for non-Network Members
4. Optional User Registration using ePin
5. Members can view full payout details in their account


==All Pages==

1. Registration New User
2. Join Network
3. Downlines
4. Account Detail
5. payout Detail


== Run Payouts :-==
To run Payout in the plugin, admin needs to be used the "Payout Run" tab in settings.
where other sub tabs also available that is used to distribut pair commission, bonus commission.


=====================
==Free Supports==
=====================
Please share your issues/feedback with us, if you are facing any while using our plugin, at letscmsdev@gmail.com

Mail: letscmsdev@gmail.com
Skype: jks0586
Whats App: +91-9717478599
Support: 24X7


== Installation ==
<b>Follow the steps for automatic installation-</b>
– Log in to your WordPress dashboard
– Navigate to the Plugins menu and click Add New
– In the search field type binary-mlm-plan and click Search Plugins
– Once you’ve found our plugin, click on Install Now
– After installation, click on activate
You are done :)
Manual Installation-
Place the binary-mlm-plan folder in your /wp-content/plugins/ directory.
Activate Binary MLM Plan.
A new menu item would be created in the admin menu called Binary MLM Plan.


