<?php
/**
 * Plugin Name: Woo-Binary-MLM
 * Description: A plugin for Woo-Binary-MLM
 * Version: 1.0
 * Author: Letscms
 * Author URI: https://www.letscms.com/
 * Text Domain: bmw
 * Domain Path: /i18n/languages/
 *
 * @package woo-binary-mlm
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define BMW_PLUGIN_FILE.
if ( ! defined( 'BMW_PLUGIN_FILE' ) ) {
	define( 'BMW_PLUGIN_FILE', __FILE__ );
}

// Define BME_ABSPATH
if ( ! defined( 'BMW_ABSPATH' ) ) {
   define( 'BMW_ABSPATH', dirname( __FILE__ ) );
}

// Define BME_URL.
if ( ! defined( 'BMW_URL' ) ) {
	define( 'BMW_URL', plugins_url( '', __FILE__ ) );
}

// Include the main Letscms_BMW class.
if ( ! class_exists( 'Letscms_BMW' ) ) {
	include_once dirname( __FILE__ ) . '/includes/class-bmw.php';
}

/**
 * Main instance of Letscms_BMW.
 *
 */
function letscms_bmw() {
	return Letscms_BMW::instance();
}

// Global for backwards compatibility.
$GLOBALS['bmw'] = letscms_bmw();