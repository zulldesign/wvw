<?php
class Bmw_Distribute_Money{
	use Letscms_BMW_CommonClass;

	public function Payoutmoney($payoutId){
		global $wpdb;
		$sql = "SELECT parent_key,  debit_left, debit_right,status,payout_id 
				FROM {$wpdb->prefix}bmw_point_transaction
				WHERE 
					payout_id = '".$payoutId."' AND status='0';"; 
		$results = $wpdb->get_results($sql);	

		$i=1; 
		$data = array(); 
		if($results && $wpdb->num_rows>0)
		{
			foreach($results as $val)
			{				
				$userKey = $val->parent_key; 
				$debit_left = $val->debit_left;
				$debit_right = $val->debit_right;
				$status = $val->status;
				$payout_id = $val->payout_id;
				
				$userId = $this->getUserIdByKey($userKey);	
				$unitArr = $this->getUnit($debit_left,$debit_right);
				
				$unit = $unitArr['unit']; 
				$total_comission = $this->getComission($userId,$unit); 
				$affiliate_commission = $this->getAffiliateCommission($userId); 
				$bonus_amount  = $this->calculateTotalBonus($userId, $unit); 
				$bonusSlabArr = $this->getBonusSlab($userId, $unit); 
			
				$tds = $this->calculateTDS($userId, $total_comission, $bonus_amount); 
				
				$payoutArr = get_option('bmw_payout_settings',true);
				$service_charges = $payoutArr['bmw_servicecharges'];
				$payableAmount = $total_comission + $affiliate_commission + $bonus_amount - $tds - $service_charges;
							
				$data[$i]['FirstName'] = get_user_meta($userId,'first_name',true);
				$data[$i]['LastName'] = get_user_meta($userId,'last_name',true);
				$data[$i]['name'] = $data[$i]['FirstName'].'&nbsp;'.$data[$i]['LastName']; 
				$data[$i]['userId'] = $userId;
				$data[$i]['userKey'] = $userKey;
				$data[$i]['payout_id'] = $payoutId;
				$data[$i]['units'] = $unit;
				$data[$i]['total_commission'] = number_format($total_comission,'2','.','');
				$data[$i]['affiliate_commission'] = number_format($affiliate_commission,'2','.','');
				$data[$i]['total_bonus'] = number_format($bonus_amount,'2','.','');
				$data[$i]['tds'] = number_format($tds,'2','.',',');
				$data[$i]['service_charges'] = number_format($service_charges,'2','.','');
				$data[$i]['net_payable'] = number_format($payableAmount,'2','.','');
				$data[$i]['bonusSlabArr'] = $bonusSlabArr;

				$i++;	
			}
		} //echo "<pre>";print_r($data); die;
		 return $data; 
	}

	public function distribute_money_calculate(){
		global $wpdb;
		$sql= "SELECT MAX(id) FROM {$wpdb->prefix}bmw_payout_master";
		$pid= $wpdb->get_var($sql);

		$action = '';
		$data = $this->Payoutmoney($pid); 
 		$adminajax= "'".admin_url('admin-ajax.php')."'";
?>	


	 
<table id="data_table">
	<thead>
		 <tr>
			<th scope="col" width="5%"><?php echo __('S.No.','bmw');?></th>
			<th scope="col" width="20%"><?php echo __('User Name','bmw');?></th>
			<th scope="col"width="8%"><?php echo __('Payout Id','bmw');?></th>
			<th scope="col" width="8%"><?php echo __('Units','bmw');?></th>
			<th scope="col" width="10%"><?php echo __('Total Commission','bmw');?></th>
			<th scope="col" width="10%"><?php echo __('Affiliate Commission','bmw');?></th>
			<th scope="col" width="10%"><?php echo __('Total Bonus','bmw');?></th>
			<th scope="col" width="8%"><?php echo __('TDS','bmw');?></th>
			<th scope="col"width="8%"><?php echo __('Service Charges','bmw');?></th>
			<th scope="col" width="15%"><?php echo __('Payable Amount','bmw');?></th>
		  </tr>
	</thead>
<?php 
	$i = 1;	
	if(count($data)>0)
	{ 
		foreach( $data as $val) 
		{
			$units = $val['units']; 
			if(isset($val['userKey']) && $val['units'] >0) { ?>
		  		<tr>
					<td style="width: 6%"><?php echo $i; ?></td>
					<td><?php echo $val['name']; ?></td>
					<td><?php echo $val['payout_id']; ?></td>
					<td><?php echo $val['units']; ?></td>
					<td><?php echo $val['total_commission']; ?></td>
					<td><?php echo $val['affiliate_commission']; ?></td>
					<td><?php echo $val['total_bonus']; ?></td>
					<td><?php echo $val['tds']; ?></td>
					<td><?php echo $val['service_charges']; ?></td>
					<td><?php echo $val['net_payable']; ?></td>
		  		</tr>
	   	<?php $i++; } 
		} 
	}else { 
			echo "<tr><td colspan='15'>".__('There is no any eligible member Found in this pay cycle.','bmw')."</td></tr>";
		  }    ?>
	<tr>
		<td colspan='15'><button type="submit" name="distribute_money" id="distribute_money" class="button-primary" onclick="savingPayoutMoney(<?php echo $adminajax;?>);" <?php echo (!empty($units) >0) ? '' : 'disabled'; ?>><?php echo __('Distribute Money in the network','bmw');?></button>
		</td>
	</tr>
</table>
<div id="saveMoney"></div>	  

<?php

/**************| Close |**********************/
	}
}
