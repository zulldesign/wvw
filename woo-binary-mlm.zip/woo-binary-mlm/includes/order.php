<?php
class Bmw_order{
	use Letscms_BMW_CommonClass; 
	
	public function totalPvForWoocommerce($order_id,$items)
	{  
	    global $wpdb;
	    $total_pv=(int)'';
	    foreach($items as $item)
	    {   
	    	$product_name = $item['name'];
	    	$product_id = $item['product_id'];
	    	$quantity = $item['quantity'];
	        $point_value=((int)get_post_meta($product_id,'product_points',true));
	        
	        $total_pv+=($quantity*$point_value);
	    }
	    return $total_pv;
	}


	public function update_order($order_id,$order_customer_id,$order_total,$items)
	{
		global $wpdb,$woocommerce; 
		$payoutArr = get_option('bmw_payout_settings',true);
		$affliate_commission_percentage=$payoutArr['bmw_referralamount'];
		$total_pv = $this->totalPvForWoocommerce($order_id,$items); 
		$insert_pv_detail = "INSERT INTO {$wpdb->prefix}bmw_pv_detail (order_id,user_id,total_amount,total_point) values ( $order_id, $order_customer_id, $order_total, $total_pv)";
		$rs = $wpdb->query($insert_pv_detail);

		$sponsor_id=$this->getSponsoridByUserId($order_customer_id);
		
		if(!empty($affliate_commission_percentage)){
			$aff_amount = (($order_total*$affliate_commission_percentage)/100);
		} else{
			$aff_amount = '0';
		}
		
		$insert_affiliate_comm = "INSERT INTO {$wpdb->prefix}bmw_affiliate_commission ( order_id,sponsor_id, user_id, 			amount,status,payout_id ) VALUES ('".$order_id."','".$sponsor_id."','".$order_customer_id."', '".$aff_amount."', 	'1','0')";
		$results = $wpdb->query($insert_affiliate_comm);
		$point = $total_pv;
		
		$listField 		= $this->getInfoByUserId($order_customer_id); //retrun the array.

		$userId 		= $listField['userId']; 
		$userKey 		= $listField['userKey'];
		$parentKey  	= $listField['parentKey']; 
		$sponsorKey		= $listField['sponsorKey'];
		$leg 			= $listField['leg'];
		$payment_status = $listField['payment_status'];
		$qualification_point = $listField['qualification_point']; 

		if(isset($userKey))
		{
			$eligSettingArr = get_option('bmw_eligibility_settings');
			$qua_pv_criteria = $eligSettingArr['bmw_personalpoint']; 

			if($qualification_point == $qua_pv_criteria)
			{ 
				$update_user_ownpv = $this->updateUserOwnPV($userKey,$point);
				if(!$update_user_ownpv) echo __("error ! Table Not Updated (1)",'bme');	

			}else{ 
				$toalQpv = $qualification_point + $point; 							
				$update_user_qpv = $this->updateUserQuaPV($user_id,$userKey,$point,$toalQpv,$qua_pv_criteria);  
				if(!$update_user_qpv) echo __("error ! Table Not Updated (2)",'bme');
			}

			if($payment_status==0)
			{
				$wpdb->query("UPDATE {$wpdb->prefix}bmw_users SET paid_at = '".date('Y-m-d H:i:s')."' WHERE `user_id`='".$userId."'");
			}
			while($parentKey!='0')
		    {
				/********| Get Current Leg |******************/
				$rs_leg= $wpdb->get_var("SELECT `leg` FROM `{$wpdb->prefix}bmw_users` WHERE `parent_key` = '".$parentKey."' AND `user_id`='".$userId."'"); 

				/********| Get Parent |***********************/
				$result = $wpdb->get_row("SELECT `user_id`,`parent_key`,`leg` FROM `{$wpdb->prefix}bmw_users` 
				WHERE `user_key` = '".$parentKey."'");

				$num_rows = $wpdb->num_rows;
				if($num_rows)
				{
					if($rs_leg==1)
					{ 
						$tran_log =$this->TransLogCreditPV($result->user_id,$userKey,0,$point);
						$update_pv = $this->distributePV($result->user_id,0,$point); 
						if(!$tran_log || !$update_pv) echo _e("Error(1) with inserting or updating",'bme'); 
					} else { 
						$tran_log= $this->TransLogCreditPV($result->user_id,$userKey,$point,0);
						$update_pv = $this->distributePV($result->user_id,$point,0);
						if(!$tran_log || !$update_pv) echo _e("Error(2) with inserting or updating",'bme'); 
					}
					$parentKey = $result->parent_key;
					$userId = $result->user_id;

				}
				else
				{
					$parentKey = '0';
				}
		    }

		}
		
	}

	/*************| End of the Main Function |******************************************/
	
	public function getInfoByUserId($userId)
	{ 
		global $wpdb;
		if(isset($userId))
		{
			$sql = "SELECT 
						`id`,`user_id`,`user_key`,`parent_key`, `sponsor_key`,
						`leg`,`payment_status`,`qualification_point`, `left_point`,`right_point`,`own_point`
					FROM 
						{$wpdb->prefix}bmw_users 
					WHERE 
						user_id = '".$userId."'";

			$results = $wpdb->get_results($sql); 
			$data = array(); 
			
			if($wpdb->num_rows=='1')
			{
				foreach($results as $row){
				$data['userId']= $row->user_id;
				$data['userKey'] = $row->user_key;
				$data['parentKey'] = $row->parent_key;
				$data['sponsorKey'] = $row->sponsor_key;
				$data['leg'] = $row->leg;
				$data['payment_status'] = $row->payment_status;
				$data['qualification_point'] = $row->qualification_point;
				}
			}
		}
		
		return $data; 
	}

	public function updateUserOwnPV($userKey,$point)
	{ 
		global $wpdb;
		$sql = "UPDATE {$wpdb->prefix}bmw_users SET own_point = own_point + ".$point." WHERE `user_key` = '".$userKey."'"; 
		$res = $wpdb->query($sql);
		if($res)
		{
			return $res; 
		}
	}

	public function updateUserQuaPV($user_id,$userKey,$point,$toalQpv,$qua_pv_criteria)
	{ 
		global $wpdb;
		if($toalQpv < $qua_pv_criteria)
		{ 
			$res = $wpdb->query("UPDATE {$wpdb->prefix}bmw_users SET qualification_point = qualification_point + ".$point.", payment_status = '1' WHERE `user_key` = '".$userKey."'");
			
		}

		else if($toalQpv >= $qua_pv_criteria)
		{ 
			$extraPv = $toalQpv - $qua_pv_criteria;
			$debitpv = $qua_pv_criteria;
			$res = $wpdb->query("UPDATE {$wpdb->prefix}bmw_users SET qualification_point = '".$debitpv."', payment_status = '2' , own_point = 
			 + ".$extraPv."
							WHERE `user_key` = '".$userKey."'");
		}
		return $res; 
	}

	public function TransLogCreditPV($userid,$child_key,$lpv,$rpv) 
	{ 
		global $wpdb;
		$sql= "SELECT `user_key`, parent_key, payment_status, qualification_point, left_point, right_point, own_point FROM {$wpdb->prefix}bmw_users WHERE `user_id` = '".$userid."'";
		$rsrow = $wpdb->get_row($sql);
		if($rsrow && $wpdb->num_rows > 0)
		{
			$opening_left = $rsrow->left_point; 
			$opening_right = $rsrow->right_point;
			$qualification_pv = $rsrow->qualification_point;
			$payment_status = $rsrow->payment_status;
	
			if($qualification_pv == 100) 
			{
				$opening_own = $rsrow->own_pv;
			}else{
				$opening_own = $qualification_pv;
			}

		}

		if($lpv!=0)
		{
			$closing_left = $opening_left + $lpv; 
			$closing_right = $opening_right;
			$closing_own = $opening_own;
		}

		if($rpv!=0)
		{
			$closing_left = $opening_left;
			$closing_right = $opening_right + $rpv;
			$closing_own = $opening_own;
		}

		$addDate = date('Y-m-d H:i:s');		
		if(isset($rsrow->user_key))
		{
			$sql_tra = "INSERT INTO {$wpdb->prefix}bmw_point_transaction 
							(
								 `parent_key`,`user_key`, 
								 `opening_left`, `opening_right`, 
								`closing_left`, `closing_right`, 
								`credit_left` ,`credit_right`, `date`
							)								
							VALUES 
							(
								'".$rsrow->user_key."','".$child_key."',
								'".$opening_left."','".$opening_right."',
								'".$closing_left."','".$closing_right."',
								'".$lpv."','".$rpv."', '".$addDate."'
							)
						"; 
			$rs_tra = $wpdb->query($sql_tra); 
		}
		return 	$rs_tra;		
	}
	
	public function distributePV($userid,$left_pv,$right_pv) 
	{ 
		global $wpdb;
		$sql = "UPDATE {$wpdb->prefix}bmw_users SET  left_point = left_point + ".$left_pv." , right_point = right_point + ".$right_pv." WHERE `user_id` = '".$userid."'";
			
		$rs = $wpdb->query($sql);  
		return $rs; 
	}
	/*End of the Main Class */

}