<?php
class BMW_Network{
	use Letscms_BMW_CommonClass;

	public function view_network_detail(){
		global $wp_query, $current_user, $wpdb; 
		$pageId = $wp_query->post->ID; 
		$userId = $current_user->ID; 
		echo "<h2>". __('My Network Details','bmw'). "</h2>";
		$this->letscms_check_user();
		
		$key = $this->get_current_user_key(); 
		//$userId = get_current_userid();
		$sponsor_name = $current_user->user_login; 
		$reg_page_id = $this->bmw_get_the_post_id_by_shortcode('[bmw_registration]');
		
		/******* code to create the affiliate Url ******/
		$affiliateURLold = site_url() . '?page_id=' . $reg_page_id . '&sp=' . $key; 
		$sponsor = $this->getSponsorName($key);
	    $affiliateURLnew = site_url() . '/letscms/' . $sponsor; 

	    $permalink = get_permalink(empty($_GET['page_id']) ? '' : $_GET['page_id']); 
	    $postidparamalink = strstr($permalink, 'page_id'); 
	    $affiliateURL = ($postidparamalink) ? $affiliateURLold : $affiliateURLnew;

	    $Dashboard = new Bmw_Dashboard();
	    $userDetail 	= $Dashboard->GetUserInfoById($userId); 
		$totalPoints		= $Dashboard->TotalBusiness($userId);
		$myLeftArr		= $Dashboard->MyTop5LeftLegMember($userId);
		$myRightArr		= $Dashboard->MyTop5RightLegMember($userId);
		$myPerSalesArr	= $Dashboard->MyTop5PersonalSales($userId);
		$myRightTotal	= $Dashboard->MyRightLegMemberTotal($userId);		
		$myLeftTotal	= $Dashboard->MyLeftLegMemberTotal($userId);
		$myPerSalesTotal= $Dashboard->MyPersonalSalesTotal($userId);
		$payoutArr		= $this->MyPayoutDetails($userId);



/********************************Graph 1****************************************/
$dataleft = array();
$dataright = array();

$months_array=array('Jan'=>1,'Feb'=>2,'Mar'=>3,'Apr'=>4,'May'=>5,'Jun'=>6,'Jul'=>7,'Aug'=>8,'Sep'=>9,'Oct'=>10,'Nov'=>11,'Dec'=>12);
$data=array();
foreach($months_array as $index=>$month_array)
	{	
		$data[$month_array]['month']=$index;
		$data[$month_array]['left']=$Dashboard->leftmonthcount($month_array,$key);
		$data[$month_array]['right']=$Dashboard->rightmonthcount($month_array,$key);
	}
		?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
	 google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {        

      // Create our data table out of JSON data loaded from server.
      var data = google.visualization.arrayToDataTable([
          ['Month', 'Left Downlines', 'Right Downlines'],
          <?php foreach($data as $key=>$value){ ?>
          	['<?php echo $value['month'];?>',  <?php echo $value['left'];?>,<?php echo $value['right'];?>],
          <?php }?>
          
        ]);
        var options = {
          title : 'Monthly downlines added by User',
          vAxis: {title: 'No. of users'},
          hAxis: {title: 'Month'},
          seriesType: 'bars',
          // series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
</script>
       

<!--------------------------------Graph 2---------------------------------------->
<?php
$commission = array();
$bonus = array();
$aff_comm = array();

$data=array();
foreach($months_array as $index=>$month_array)
	{	
		$data[$month_array]['month']=$index;
		$data[$month_array]['commssion']=$Dashboard->getcommission($month_array,$userId);
		$data[$month_array]['bonus']=$Dashboard->getbonus($month_array,$userId);
		$data[$month_array]['aff_comm']=$Dashboard->getaffcomm($month_array,$userId);
	}
//echo "<pre>"; print_r($data);	

?>

<script type="text/javascript">
	 google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawVisualization);

      function drawVisualization() {        

      // Create our data table out of JSON data loaded from server.
      var data = google.visualization.arrayToDataTable([
          ['Month', 'Commission Amount', 'Bonus Amount','Affiliate Commission Amount'],
          <?php foreach($data as $key=>$value){ ?>
          	['<?php echo $value['month'];?>',  <?php echo $value['commssion'];?>,<?php echo $value['bonus'];?>,<?php echo $value['aff_comm'];?>],
          <?php }?>
          
        ]);
        var options = {
          title : 'Monthly payout earned by User',
          vAxis: {title: 'Amount'},
          hAxis: {title: 'Month'},
          seriesType: 'bars',
          // series: {5: {type: 'line'}}
        };

        var chart = new google.visualization.ComboChart(document.getElementById('payout_chart'));
        chart.draw(data, options);
      }
</script>

<div class="card">
  <div class="card-body">
    <h6 class="card-title"><strong><?php echo __('Affiliate URL','bmw');?> :</strong> </h6>
    <a href="<?php echo $affiliateURL; ?>" class="card-link" target="_blank"><?php echo $affiliateURL ?></a>
  </div>
</div>

<!-- show the Graph -->
<div class="card">
	<div id="chart_div" style="width: 900px; min-height: 500px;"></div>
</div>
<div class="card">
	<div id="payout_chart" style="width: 900px; min-height: 500px;"></div>
</div>


<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Personal Details','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
				<thead>
					<tr>
						<th class="head1"><?php echo __('Title','bmw');?></th>
						<th class="head1"><?php echo __('Details','bmw');?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo __('UserId','bmw');?></td>
						<td><?php echo $userDetail['id'] ?></td>
					</tr>
					<tr>
						<td><?php echo __('UserKey','bmw');?></td>
						<td><?php echo $userDetail['userKey'] ?></td>
					</tr>
					<tr>
						<td><?php echo __('Name','bmw');?></td>
						<td><?php echo $userDetail['name']?></td>
					</tr>
					<tr>
						<td><?php echo __('Email Id','bmw');?></td>
						<td><?php echo $userDetail['email'] ?></td>
					</tr>
					<tr>
						<td><?php echo __('Address','bmw');?></td>
						<td><?php echo $userDetail['address1']?></td>
					</tr>
					<tr>
						<td><?php echo __('City','bmw');?></td>
						<td><?php echo $userDetail['city']?></td>
					</tr>
					
				</tbody>
			</table>
		</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Total Points','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
				<thead>
					<tr>
						<th class="head1"><?php echo __('Left','bmw');?></th>
						<th class="head1"><?php echo __('Right','bmw');?></th>
						<th class="head1"><?php echo __('Total','bmw');?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo $totalPoints['left']?></td>
						<td><?php echo $totalPoints['right']?></td>
						<td><?php echo $totalPoints['total']?></td>
					</tr>
				</tbody>
			</table>
		</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Payout Details','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
				<thead>
					<tr>
						<th><?php echo __('Date','bmw');?></th>
						<th><?php echo __('Amount','bmw');?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($payoutArr as $payout  ) : ?>
					<tr>
						<td><?php echo $payout['payout_date']?></td>
						<td><?php echo $payout['paidAmount']?></td>
					</tr>
					<?php endforeach ?>
				</tbody>
				</table>
		</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Left Leg','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
				<thead>
					<tr>
						<th><?php echo __('Name','bmw');?></th>
						<th><?php echo __('Status','bmw');?></th>
					</tr>
				</thead>
				<tbody>
				
					<?php foreach($myLeftArr as $myleft  ) : ?>
					<tr>
						<td><?php echo $myleft['name']?></td>
						<td><?php echo $myleft['payment_status']?></td>
					</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Right Leg','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
			<thead>
				<tr>
					<th ><?php echo __('Name','bmw');?></th>
					<th ><?php echo __('Status','bmw');?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($myRightArr as $myright  ) : ?>
				<tr>
					<td><?php echo $myright['name']?></td>
					<td><?php echo $myright['payment_status']?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
			</table>
		</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h6 class="card-title"><strong><?php echo __('Personal Sales','bmw');?> :</strong> </h6>
		<p class="card-text">
			<table class="table table-hover">
			<thead>
				<tr>
					<th><?php echo __('Name','bmw');?></th>
					<th><?php echo __('Status','bmw');?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($myPerSalesArr as $myPerSales  ) : ?>
				<tr>
					<td><?php echo $myPerSales['name']?></td>
					<td><?php echo $myPerSales['payment_status']?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
			</table>
		</p>
	</div>
</div>


<?php
	}
}