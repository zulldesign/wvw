<?php
class BMW_woocommerce_register{

	public function bmw_register_form()
	{ 
		include BMW_ABSPATH.'/includes/catalog/html/bmw_register_form.php';
	}
}