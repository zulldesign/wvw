<?php
defined( 'ABSPATH' ) || exit;

/**
 * Letscms_BMW_Install Class.
 */
class Letscms_BMW_Install {

	public static function install(){ 
		self::create_roles();
		self::create_tables();
		self::create_pages();
		self::save_options();
	}		

/*================================Create Roles=======================================*/
	
	public static function create_roles() { 
		global $wp_roles;

		if ( ! class_exists( 'WP_Roles' ) ) {
			return;
		}

		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles(); // 
		}
		add_role('bmw_user','BMW Users',array());
	}

/*================================Create Tables=======================================*/	
	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql= "show tables like '%bmw%'"; 
		$bmw_tables = $wpdb->get_results($sql); 
		if(empty($bmw_tables))
			{ 
				dbDelta( self::get_schema() );
			} 
	}

	private static function get_schema() {
		global $wpdb;

		$collate = '';

		if ( $wpdb->has_cap( 'collation' ) ) {
			$collate = $wpdb->get_charset_collate();
		}

		$tables = "CREATE TABLE {$wpdb->prefix}bmw_users (
						id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
						user_id BIGINT NOT NULL,
						user_key VARCHAR( 15 ) NOT NULL,
						parent_key VARCHAR( 15 ) NOT NULL,
						sponsor_key VARCHAR( 15 ) NOT NULL,
						leg ENUM(  '1',  '0' ) NOT NULL,
						payment_status ENUM('0','1','2') NOT NULL,
						qualification_point INT(11) NOT NULL,
						left_point float NOT NULL,
						right_point float NOT NULL,
						own_point float NOT NULL,
						created_at datetime NOT NULL,
						paid_at datetime NOT NULL
					) $collate;
					CREATE TABLE {$wpdb->prefix}bmw_leftleg(
						id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
						user_key VARCHAR( 15 ) NOT NULL,
						parent_key VARCHAR( 15 ) NOT NULL
					) $collate;
					CREATE TABLE {$wpdb->prefix}bmw_rightleg(
						id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
						user_key VARCHAR( 15 ) NOT NULL,
						parent_key VARCHAR( 15 ) NOT NULL
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_point_transaction(
						id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
						user_key VARCHAR( 15 ) NOT NULL,
						parent_key VARCHAR( 15 ) NOT NULL,
						opening_left float NOT NULL,
						opening_right float NOT NULL,
						closing_left float NOT NULL,
						closing_right float NOT NULL,
						debit_left float NOT NULL,
						debit_right float NOT NULL,
						credit_left float NOT NULL,
						credit_right float NOT NULL,
						payout_id INT(11) NOT NULL,
						date date NOT NULL,
						status enum('0','1') NOT NULL
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_payout(	
						id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
						userid BIGINT  NOT NULL,
						date date NOT NULL,
						payout_id int(11) NOT NULL,
						units int(25) NOT NULL,
						commission_amount double(10,2) DEFAULT '0',
						affiliate_commission double(10,2) DEFAULT '0',
						bonus_amount double(10,2) DEFAULT '0',
						neft_code varchar(10) DEFAULT NULL,
						cheque_no varchar(10) DEFAULT NULL,
						cheque_date varchar(10) DEFAULT NULL,
						bank_name varchar(50) DEFAULT NULL,
						user_bank_name varchar(50) DEFAULT NULL,
						user_bank_account_no varchar(10) DEFAULT NULL,
						tds double(10,2) DEFAULT '0',
						service_charge double(10,2) DEFAULT '0',
						dispatch_at date DEFAULT NULL,
						courier_name varchar(20) DEFAULT NULL,
						awb_no varchar(20) DEFAULT NULL
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_payout_master(	
						id int(10) unsigned NOT NULL auto_increment PRIMARY KEY,
						date date NOT NULL
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_bonus(	
						id int(10) unsigned NOT NULL auto_increment PRIMARY KEY,
						units int(11) NOT NULL,
						amount float NOT NULL,
						created_at datetime NOT NULL,
						lastupdate datetime NOT NULL,
						status char(1) NOT NULL COMMENT '0-Active, 1-Inactive'
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_bonus_payout(
						id int(10) unsigned NOT NULL auto_increment PRIMARY KEY,
						user_id int(11) NOT NULL,
						bonus_id int(11) NOT NULL,
						amount float NOT NULL,
						payout_id int(11) NOT NULL,
						date datetime NOT NULL
					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_pv_detail(
						id int(11) unsigned NOT NULL auto_increment PRIMARY KEY,
						order_id int(11) NOT NULL UNIQUE KEY,
						user_id int(11) NULL,
						total_amount int(11) NOT NULL,
						total_point int(11) NOT NULL,
						status int(11) NOT NULL DEFAULT '0'

					) $collate;

					CREATE TABLE {$wpdb->prefix}bmw_affiliate_commission(
						id int(11) unsigned NOT NULL auto_increment PRIMARY KEY,
						order_id int(11) NOT NULL,
						sponsor_id int(11) NOT NULL,
						user_id int(11) NOT NULL,
						amount int(11) NOT NULL,
						status int(11) NOT NULL  DEFAULT '0',
						payout_id int(11) NOT NULL
					) $collate;

					";

		return $tables;

}

/*================================Create Pages=======================================*/
	private static function create_pages(){
		global $wpdb;
		$bmwpages = array(
			'my-networks-page' => array(
				'name' => 'my-networks-page',
				'title' => __( 'My Networks', 'bmw' ),
				'tag' => '[bmw_network]',
				'option' => 'my_networks_url'
			),
			'my-direct-group-details-page' => array(
				'name' => 'my-direct-group-details-page',
				'title' => __( 'My Direct Group Details', 'bmw' ),
				'tag' => '[bmw_directgroup]',
				'option' => 'my_direct_group_url'
			),
			'my-left-group-details-page' => array(
				'name' => 'my-left-group-details-page',
				'title' => __( 'My Left Group Details', 'bmw' ),
				'tag' => '[bmw_leftgroup]',
				'option' => 'my_left_group_url'
			),
			
			'my-right-group-details-page' => array(
				'name' => 'my-right-group-details-page',
				'title' => __( 'My Right Group Details', 'bmw' ),
				'tag' => '[bmw_rightgroup]',
				'option' => 'my_right_group_url'
			),
			
			'unpaid-details-page' => array(
				'name' => 'unpaid-details-page',
				'title' => __( 'Unpaid Consultants', 'bmw' ),
				'tag' => '[bmw_unpaid_consultant]',
				'option' => 'my_unpaid_consultant_url'
			),
			
			'my-downlines' => array(
				'name' => 'my-downlines',
				'title' => __( 'My Downlines', 'bmw' ),
				'tag' => '[bmw_downlines]',
				'option' => 'my_downlines_url'
			),
			
			'registration-page' => array(
				'name' => 'registration-page',
				'title' => __( 'Registration', 'bmw' ),
				'tag' => '[bmw_registration]',
				'option' => 'registration_url'
			),
			'join-networks-page' => array(
				'name' => 'join-networks-page',
				'title' => __( 'Join Network', 'bmw' ),
				'tag' => '[bmw_join_network]',
				'option' => 'join_networks_url'
	        ),
	        'user-account-details' => array(
				'name' => 'user-account-details',
				'title' => __( 'User Account Details', 'bmw' ),
				'tag' => '[bmw_user_account_details]',
				'option' => 'user_account_details_url'
	        )
		); 
		$newmlmpages = false;	

		$menu = wp_get_nav_menu_object( 'primary' ); 
		if(empty($menu))
		{
			wp_update_nav_menu_object( 0, array('menu-name' => 'primary') );
		}
		$menu = wp_get_nav_menu_object( 'primary' );

		$args = array(
						"post_type" => "nav_menu_item", 
						"name" => 'BMW',
						"title"=>'Binary MLM WooCommerce'
					);
		
		$query = new WP_Query( $args );

			if(empty($query->posts)){
			 	$parent_id=wp_update_nav_menu_item($menu->term_id, 0, array(
		 				'menu-item-title' =>  __('Binary MLM WooCommerce'),
		 				'menu-item-classes' => 'bmw',
		 				'menu-item-url' => '#',
		 				'menu-item-status' => 'publish',
		 				'menu-item-type' => 'custom',
				 		)
				 );

			 	update_post_meta( $parent_id, 'menu_item_bmw','Binary MLM WooCommerce');
		 	}
		 	 else {
		 	 	$parent_id=$query->posts[0]->ID;
		 	 }

	//create the pages

		foreach ( $bmwpages as $key => $page ) {
			$page_id=get_page_by_title( $page['title'], OBJECT, 'page');
			
			if(empty($page_id)){
				$pageid=self::bmw_create_page( $page['title'], $page['tag'], $page['name'], $page['option']);
				wp_update_nav_menu_item($menu->term_id,0, array(
				'menu-item-object-id' => $pageid,
				'menu-item-object' => 'page',
				'menu-item-title' =>  $page['title'],
				'menu-item-classes' => 'bmw',
				'menu-item-status' => 'publish',
				'menu-item-type' => 'post_type',
				'menu-item-parent-id' => $parent_id,
			));
			}
		}
	}

	public static function bmw_create_page( $page_title = '', $page_content = '', $page_name = '', $page_option = '') {
		global $wpdb;
		$page_data = array(
			'post_status'    => 'publish',
			'post_type'      => 'page',
			'post_title'     => $page_title,
			'post_content'   => $page_content,
			'post_name'		=>	$page_name,
		);
		
		$page_id   = wp_insert_post( $page_data );
		$newmlmpages = true;
		update_option( $page_option, get_permalink( $page_id ) );
		update_post_meta($page_id, 'bmw_page_title',$page_title);
		if($page_title!='Registration' AND $page_title!='Join Network')
			{
				update_post_meta( $page_id, 'is_mlm_page',true);
			}
		return $page_id;
	}




/*================================Save Default Values=======================================*/
	private static function save_options(){

		$general = array('letscms_purchase_reg' => '1', 'letscms_affiliate_url' => 'registration-page/');
		update_option('bmw_general_settings', $general);

		$mapping = array('letscms_woocommerce_payment' => 'wc-completed');
		update_option('bmw_mapping_settings',$mapping);

		$eligibility =array('bmw_personalpoint' => '100', 'bmw_directreferrer' => '2', 'bmw_leftreferrer' => '1', 'bmw_rightreferrer' => '1', 'bmw_minpoint' => '');
		update_option('bmw_eligibility_settings', $eligibility); 

		$payout = array('bmw_pair1' => '100', 'bmw_pair2' => '100', 'bmw_initialunits' => '2', 'bmw_initialrate'=>'1000', 'bmw_furtheramount' => '500', 'bmw_servicecharges'=>'100', 'bmw_tds'=>'2', 'bmw_capamount'=>'200000');
		update_option('bmw_payout_settings', $payout);
		
	}




	/*=============================Deactivate the plugin====================================*/

	public static function deactivate() {
		global $wpdb;

		$mlmPages = array('My Networks','My Direct Group Details','My Left Group Details','My Right Group Details','Unpaid Consultants','My Downlines','Registration','Join Network');
		

			//delete post from wp_posts and wp_postmeta table
			foreach($mlmPages as $value)
			{
				$post_id = $wpdb->get_var("SELECT id from {$wpdb->prefix}posts where post_title = '$value'" );
				wp_delete_post( $post_id, true );
			}

			foreach($mlmPages as $value)
			{
				$results = $wpdb->get_results("SELECT p.id from {$wpdb->prefix}posts as p join {$wpdb->prefix}postmeta as pm on p.id=pm.post_id where pm.meta_key='bmw_page_title' AND pm.meta_value = '$value'" );
				foreach($results as $result)
					{
						wp_delete_post( $result->id, true );
					}
			}

			$results = $wpdb->get_results("SELECT p.id from {$wpdb->prefix}posts as p join {$wpdb->prefix}postmeta as pm on p.id=pm.post_id where pm.meta_key='menu_item_bmw' AND pm.meta_value = 'Binary MLM WooCommerce'" );
				foreach($results as $result)
				{
					wp_delete_post( $result->id, true );
				}

		$wp_roles = new WP_Roles();
		$wp_roles->remove_role("bmw_user");
	}
}