<?php 

trait Letscms_BMW_CommonClass{

	function letscms_check_user($id=''){
	global $wpdb, $current_user;

		if ( !is_user_logged_in() ) {   
			echo $url = site_url('wp-login.php'); 
			echo "<script>window.location='$url'</script>";
			exit;
		}

		if($id=='')
			{
				$user_id=$current_user->ID; 
			} else{
				$user_id=$id;
			}

		$user_meta=get_userdata($user_id);

			if ( is_user_logged_in() ) { 
				$user_roles=$user_meta->roles; 

					//if ( ! empty( $user_roles ) && is_array( $user_roles ) && in_array( 'bmw_user', $user_roles ) || in_array('administrator', $user_roles) ){

					 if ( ! empty( $user_roles ) && is_array( $user_roles ) && in_array( 'bmw_user', $user_roles ) ){
						return true;
					} else{	?>
							<div class="container">
							<p>
							You are not a <b>MLM user</b>. To access this page , you must first register as MLM user . <br>Please contact the system admin at <?php echo get_option('admin_email') ?> to report this problem.
							</p>
							</div>
						<?php die;
						}
			}

		}

	function getUserNameById($id)
	{
		global $wpdb;
		$name = '';
		$name .= ucfirst(strtolower(get_user_meta($id,'first_name',true))).' ';
		$name .= ucfirst(strtolower(get_user_meta($id,'last_name',true)));
		return $name;
	}


	function getSponsoridByUserId($userid)
	{
		global $wpdb;
		if(isset($userid))
		{
			$sql = "SELECT sponsor_key FROM {$wpdb->prefix}bmw_users WHERE user_id = '".$userid."'";	
			$sponsor_key = $wpdb->get_var($sql);

			$sql_user_id = "SELECT user_id FROM {$wpdb->prefix}bmw_users WHERE user_key = '".$sponsor_key."'";	
			$sponsor_id = $wpdb->get_var($sql_user_id);
		}
		return $sponsor_id; 
	}

	function getKeyByUserId($userid)
	{
		global $wpdb;
		if(isset($userid))
		{
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_users WHERE user_id = '".$userid."'";	
			$userKey = $wpdb->get_var($sql);
		}
		return $userKey; 
	}

	function getUserNameByUserId($id)
    {
        global $wpdb;
        $sql="SELECT user_login FROM $wpdb->users WHERE ID='".$id."'";
        $username = $wpdb->get_var($sql); 
        return $username;
    }

    function getUserIdByKey($userKey)
	{ 
		global $wpdb;
		if(isset($userKey))
		{
			$sql = "SELECT user_id FROM {$wpdb->prefix}bmw_users WHERE user_key = '".$userKey."'";	
			$userId = $wpdb->get_var($sql); 
			return $userId;
		}
		return false; 
	}

	function checkInputField($value)
	{
		if($value=="")
			return true;
		else
			return false;
	}

	function confirmPassword($pass, $confirm)
	{
		if($confirm != $pass)
			return true;
		else
			return false;
	}

	function confirmEmail($email, $confirm)
	{
		if($confirm != $email)
			return true;
		else 
			return false;
	}

	/****************************To Register user*******************************/
	function letscms_generateKey()
	{
		// Random characters
		$characters = array("0","1","2","3","4","5","6","7","8","9");

		// set the array
		$keys = array();

		// set length
		$length = 9;

		// loop to generate random keys and assign to an array
		while(count($keys) < $length) 
		{
			$x = mt_rand(0, count($characters)-1);
			if(!in_array($x, $keys)) 
				$keys[] = $x;
		}

		// extract each key from array
		$random_chars='';
		foreach($keys as $key)
			$random_chars .= $characters[$key];

		// display random key
		return $random_chars;
	}

	function checkKey($key)
	{
		global $wpdb;
		$query = $wpdb->get_var("SELECT user_key FROM {$wpdb->prefix}bmw_users WHERE `user_key` = '".$key."'");
		if($wpdb->num_rows<1)
		{
			return false;
		}
		return true;
	}

	function checkallowed($key,$leg=NULL)
	{
		global $wpdb;
		$query = $wpdb->get_var("SELECT user_id FROM {$wpdb->prefix}bmw_users WHERE leg = '".$leg."' AND parent_key = '".$key."'");
		$num = $wpdb->num_rows;
		return $num;
	}

	function GetUserInfoById($id)
	{ 
		global $wpdb;	
		$sql = "SELECT ID,user_login,user_pass,user_email FROM `{$wpdb->users}` WHERE ID = '".$id."'";
		$results = $wpdb->get_results($sql); 
		$userDetail = array();
		if($results && $wpdb->num_rows>0)
		{
			foreach($results as $row){
				$userId = $row->ID; 
				$userDetail['id'] = $userId;
				$userDetail['userlogin'] = $row->user_login;
				$userDetail['email'] = $row->user_email;
				$userDetail['name'] = $this->getUserNameById($userId);
				$userDetail['address1'] = get_user_meta($userId,'user_address1', true);
				$userDetail['city'] = get_user_meta($userId,'user_city', true);
				$userDetail['state'] = get_user_meta($userId,'user_state', true);
				$userDetail['zipcode'] = get_user_meta($userId,'user_postalcode', true);
				$userDetail['country'] = get_user_meta($userId,'user_country', true);
				$userDetail['phone'] = get_user_meta($userId,'user_telephone', true);
				}		
		}
	
			$sql1 = "SELECT user_id,user_key,sponsor_key,DATE_FORMAT(`created_at`,'%d %b %Y') as creationDate, 
						payment_status FROM {$wpdb->prefix}bmw_users WHERE user_id ='".$id."'";
			$results1 = $wpdb->get_results($sql1);					

			if($results1 && $wpdb->num_rows>0)
			{
				foreach($results1 as $row){
					$userDetail['userKey'] = $row->user_key;
					
					if($row->sponsor_key!=0)
						$userDetail['referrer'] = $this->getReferrerByKey($row->sponsor_key);
					else
						$userDetail['referrer'] = 'None';
						
					$userDetail['creationDate'] = $row->creationDate;
					$userDetail['payment_status_code'] = $row->payment_status;
					$userDetail['payment_status'] = $row->payment_status;
				}
			}
		return $userDetail;		
	}

	function getSponsorName($sponsor_key)
    {
    	global $wpdb;
        $referrer='';
		if(isset($sponsor_key))
		{
			$sql = "SELECT `user_id` FROM {$wpdb->prefix}bmw_users WHERE `user_key` = '".$sponsor_key."'";	
			$user_id = $wpdb->get_var($sql);
					
			if($wpdb->num_rows==1)
			{
				$sql = "SELECT user_login FROM $wpdb->users WHERE ID = '".$user_id."'";
                $referrer=$wpdb->get_var($sql);
			}
		}
	return $referrer; 
    }

    function getReferrerByKey($userKey)
    {
    	global $wpdb;
		$referrer='';
		if(isset($userKey))
		{
			$sql = "SELECT `user_id` FROM {$wpdb->prefix}bmw_users WHERE `user_key` = '".$userKey."'";	
			$user_id = $wpdb->get_var($sql);
					
			if($wpdb->num_rows==1)
			{
				$referrer = $this->getUserNameById($user_id);
			}
		}
		return $referrer; 
	}

	function get_current_user_key()
	{ 
		global $wpdb;
		$current_user = wp_get_current_user();
		$userId = $current_user->ID; 
		$userKey = '';
		if(isset($userId) && $userId!='')
		{
			$result = $wpdb->get_var("SELECT `user_key` FROM {$wpdb->prefix}bmw_users WHERE user_id = '".$userId."'"); 
			if($result && $wpdb->num_rows>0)
			{
				$userKey =  $result;
			}
		} 
		return $userKey; 
	}

	function getSponsorKeyBySponsorname($sponsorName) { 
		global $wpdb;
		$sql = "SELECT ID FROM $wpdb->users WHERE user_login = '" . $sponsorName . "'";
		$ID = $wpdb->get_var($sql);

		if ($wpdb->num_rows == 1)
		{
			$userId = $ID;
		} else{
			$userId = '';
		}
		$sql1 = "SELECT user_key FROM {$wpdb->prefix}bmw_users WHERE user_id = '" . $userId . "'";
		$result = $wpdb->get_var($sql1);

		if ($wpdb->num_rows == 1)
		{
			$user_key = $result;
			return $user_key;
		}
		return false;
	}

	function MyPayoutDetails($userid)
	{
		global $wpdb;
		$sql = "SELECT DATE_FORMAT(`date`,'%d %b %Y') as payout_date, payout_id, 												units,commission_amount,affiliate_commission,bonus_amount,tds, service_charge
						FROM {$wpdb->prefix}bmw_payout
						WHERE userid = '".$userid."' ORDER BY id desc";
		$results = $wpdb->get_results($sql);
		$i=1;
		$data=array();
		if($wpdb->num_rows>0)
		{
			foreach($results as $row)
			{
				$data[$i]['payout_date'] = $row->payout_date;
				$data[$i]['payout_id'] = $row->payout_id;
				$data[$i]['pair'] = $row->units;
				$commission = $row->commission_amount;
				$aff_comm = $row->affiliate_commission;
				$bonus = $row->bonus_amount;
				$serviceCharge = $row->service_charge;
				$tds = $row->tds;
				$data[$i]['paidAmount'] = $commission + $aff_comm + $bonus - $serviceCharge - $tds ;
			   $i++;
			}
				
		}else{
			$data[$i]['payout_date'] = __('No Payout Available','bmw');
			$data[$i]['paidAmount'] = '';
		}
		return $data;
	}


	function checkValidParentKey($key)
	{
		global $wpdb;
		$sql = "SELECT user_id FROM {$wpdb->prefix}bmw_users WHERE user_key = '".$key."'";
		$query = $wpdb->get_var($sql);
		if($wpdb->num_rows>0)
			return true;
		else
			return false;
	
	}

	function checkValidSponsor($sponsorName) {
	global $wpdb;
	$sql = "SELECT ID FROM $wpdb->users WHERE user_login = '" . $sponsorName . "'";
	$results = $wpdb->get_var($sql);

	if ($wpdb->num_rows == 1)
	{

		$userId = $results;
		$sql1 = "SELECT user_key FROM {$wpdb->prefix}bmw_users WHERE user_id = '" . $userId . "'";
		$result1 = $wpdb->get_var($sql1);

		if ($wpdb->num_rows == 1)
		{
			return true;
		}
		return false;
	}
	return false;
	}

	function bmw_get_the_post_id_by_shortcode($shortcode){
		global $wpdb;
		$sql = "SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type` IN('page','post') AND `post_content` LIKE '%" . $shortcode. "%' LIMIT 1";
		$page_id = $wpdb->get_var($sql); 
		return apply_filters( 'bmw_get_the_post_id_by_shortcode', $page_id );
	}



/************************************Payout functions**********************************
**************************************************************************************/
public function checkUserPaymentStatus($user_id){ 
	global $wpdb;
	$return_val = 0;
		if(isset($user_id))
		{
			$sql = "SELECT user_id, payment_status FROM {$wpdb->prefix}bmw_users WHERE user_id = '".$user_id."' ";
			$row = $wpdb->get_row($sql);

			if($wpdb->num_rows>0){
				$payment_status = $row->payment_status;
				if($payment_status==2 || $payment_status==1){
					$return_val = "TRUE";
				}else{
					$return_val = "FALSE";
				}
			}
		}
		return $return_val;	
}

 /* Check the user Sponcered as per the settings left and right leg. */
    public function checkSponsoredLeftAndRight($userKey)
    {
    	global $wpdb;
		if(isset($userKey))
		{						
			$leftSide = 0;
			$rightSide = 0;
			$status = '';
			
		$sql = "SELECT user_id,user_key,sponsor_key,leg FROM {$wpdb->prefix}bmw_users WHERE sponsor_key = '".$userKey."' AND payment_status IN ('1','2')";
		$results = $wpdb->get_results($sql);

			if($results && $wpdb->num_rows>0){
				foreach($results as $row){
					$leg = $row->leg;

					if($leg==0){
						$leftSide = $leftSide + 1; 										
					}else if($leg==1){
						$rightSide = $rightSide + 1;
					}
				}
				$referrerCriteria =  get_option( 'bmw_eligibility_settings', true );
				if( ($leftSide >= $referrerCriteria['bmw_leftreferrer'] && $rightSide >= $referrerCriteria['bmw_rightreferrer']) || ($leftSide >= $referrerCriteria['bmw_rightreferrer'] &&  $rightSide >= $referrerCriteria['bmw_leftreferrer'] ) )
					{
						$status = "TRUE";						
					
					}else{
						$status = "FALSE";
					}
			} else {
				$status = "FALSE";
			}
		
   		}
   		return $status; 	
   	}

   	/* Check the member has how many directly sponsored */
   public function checkDirectSponsored($userKey)
   {
   		global $wpdb;
		if(isset($userKey))
		{
			$totalCriteria = 0;			
			$sql = "SELECT COUNT(user_key) AS total FROM {$wpdb->prefix}bmw_users 
					WHERE sponsor_key = '".$userKey."' AND payment_status IN ('1','2')";
			$count_member = $wpdb->get_var($sql);
			if($count_member && $wpdb->num_rows>0){
				$total = $count_member;
				$referrerCriteria =  get_option( 'bmw_eligibility_settings', true );
				if($total >= $referrerCriteria['bmw_directreferrer'])
				{
					$totalCriteria = "TRUE"; 
				}else{
					$totalCriteria = "FALSE";
				}

			}
		}
		return $totalCriteria; 	
   }

	public function GetNowRightPoint($leftPV,$rightPV,$ownPV)
	{
		if($leftPV >$rightPV){
			$nowRightPV = $ownPV + $rightPV; 
		}else if($rightPV >$leftPV){
			$nowRightPV = $rightPV;
		}else if($leftPV = $rightPV){
			$nowRightPV = $rightPV;
	}

	return $nowRightPV; 
	}

	public function GetNowLeftPoint($leftPV,$rightPV, $ownPV)
	{

		if($leftPV >$rightPV){
			$nowLeftPV = $leftPV;
		}else if($rightPV >$leftPV){
			$nowLeftPV = $ownPV + $leftPV;
		}else if($leftPV == $rightPV){
			$nowLeftPV = $leftPV;
		}
		return $nowLeftPV; 
	}

	public function GetNowOwnPoint($leftPV,$rightPV, $ownPV)
	{

		if($leftPV >$rightPV){
			$nowOwnPV = 0;
		}else if($rightPV >$leftPV){
			$nowOwnPV = 0;
		}else if($leftPV == $rightPV){
			$nowOwnPV = $ownPV;
		}
		return $nowOwnPV; 
	}

    public function getUnit($leftcount, $rightcount)
	{
		$directCaseArr = $this->getUnitByDirectCase($leftcount,$rightcount);
		$oppisiteCaseArr = $this->getUnitByOppositeCase($leftcount,$rightcount);
		
		if($directCaseArr['unit'] >= $oppisiteCaseArr['unit'])
		{
			$returnArr = $directCaseArr; 	
		}else{
			$returnArr = $oppisiteCaseArr;
		}
		return $returnArr; 			
		
	}

	public function getUnitByDirectCase($leftcount, $rightcount)
	{
		$pair = get_option('bmw_payout_settings');
		$pair1 = $pair['bmw_pair1'];
		$pair2 = $pair['bmw_pair2']; 
			
		$leftunit = (int)($leftcount/$pair1);
		$rightunit = (int)($rightcount/$pair2);
		
		if($leftunit <= $rightunit)
		$unit = $leftunit;
		else
		$unit = $rightunit;
		
		$leftbalance = $leftcount - ($unit * $pair1);
		$rightbalance = $rightcount - ($unit * $pair2);
			
		$array['leftbal'] = $leftbalance;
		$array['rightbal'] = $rightbalance;
		$array['unit'] = $unit;
	
		return $array;
	}
	
	public function getUnitByOppositeCase($leftcount, $rightcount)
	{
		$pair = get_option('bmw_payout_settings');
		$pair1 = $pair['bmw_pair2'];
		$pair2 = $pair['bmw_pair1'];
		
		$leftunit = (int)($leftcount/$pair1);
		$rightunit = (int)($rightcount/$pair2);
		
		if($leftunit <= $rightunit)
		$unit = $leftunit;
		else
		$unit = $rightunit;
		
		$leftbalance = $leftcount - ($unit * $pair1);
		$rightbalance = $rightcount - ($unit * $pair2);
			
		$array['leftbal'] = $leftbalance;
		$array['rightbal'] = $rightbalance;
		$array['unit'] = $unit;
		
		return $array;
	}

	public function getComission($userid,$unit)
	{ 
		global $wpdb; 
		$sql = "SELECT sum(units) FROM {$wpdb->prefix}bmw_payout WHERE userid = '".$userid."' ";
		$pre_unit = $wpdb->get_var($sql); 
		$totalUnit = $pre_unit + $unit;
		
		/*Rate Criteria */
		$payout = get_option('bmw_payout_settings',true);

		$initialrate 	 = $payout['bmw_initialrate'];
		$initialunits		 = $payout['bmw_initialunits'];
		$furtheramount	 = $payout['bmw_furtheramount'];
		$capLimitAmount		 = $payout['bmw_capamount'];
		
		if($totalUnit < $initialunits)
		{
			$pay = $unit * $initialrate; 
		}
		elseif($totalUnit >= $initialunits)
		{
			if($pre_unit <= $initialunits)
			{			
				$pay1 = $initialunits - $pre_unit;
				$pay2 = $unit - $pay1; 	
				$pay = $pay1* $initialrate + $pay2 * $furtheramount;  
			}else{
				$pay = $unit * $furtheramount;
			}	
		}
		
		if($pay > $capLimitAmount)
		{
			$comission = $capLimitAmount;
		}else{
			$comission = $pay; 
		}			
		return $comission; 	
	}

   	public function getAffiliateCommission($userId)
	{ 
		global $wpdb;
		if(isset($userId))
		{
			$sql = "SELECT SUM(amount) as amount FROM {$wpdb->prefix}bmw_affiliate_commission WHERE sponsor_id = '".$userId."' AND status=1 AND payout_id=0";
			$results = $wpdb->get_var($sql);
			if($wpdb->num_rows =='1')		
			{
				$amount = $results;
			}
		}
		return $amount; 
	}

	public function calculateTotalBonus($userid, $unit)
	{
		global $wpdb;	
		$sql = "SELECT sum(units) FROM {$wpdb->prefix}bmw_payout WHERE userid = '".$userid."' ";
		$result= $wpdb->get_var($sql);
		$old_unit = $result;
		if($old_unit==''){ $old_unit = 0; } 
		$current_unit = $unit;
		$total_unit = $old_unit + $current_unit; 
		$totalbonus = 0;
		
		$bonusTakenArr = $this->getTakenBonus($userid);
		//echo "<pre>";print_r($bonusTakenArr); exit; 
		if($bonusTakenArr){
		$bonusTaken = implode(",", $bonusTakenArr);
		} else{
			$bonusTaken ='';
		}
	
		$sql_bonus = "SELECT SUM(amount) AS total FROM {$wpdb->prefix}bmw_bonus
					  WHERE units <= '".$total_unit."'  AND 
							id NOT IN (".$bonusTaken.") AND 
							status = 0";
		$rs_bonus = $wpdb->get_var($sql_bonus);
 
		if($rs_bonus && $wpdb->num_rows>0)
		{
			$totalbonus = $rs_bonus;
			if($totalbonus==''){
				$totalbonus=0;
			}
		}
		return $totalbonus;
	}

	public function getTakenBonus($userid)
	{
		global $wpdb;
		if(isset($userid))
		{
			$sql = "SELECT bonus_id,amount FROM {$wpdb->prefix}bmw_bonus_payout WHERE user_id = '".$userid."'";	
			$results = $wpdb->get_results($sql);
			$i=1;
			$bonusArr= array();	
			if($results && $wpdb->num_rows>0)	
			{
				foreach($results as $row)
				{
					$bonusArr[$i] = $row->bonus_id;
					$i++;
				}
			}else{
				$bonusArr[$i]=0;
			}
		}
		return $bonusArr; 
	}

	public function getBonusSlab($userid, $unit)
	{
		global $wpdb;
		$sql = "SELECT sum(units) FROM {$wpdb->prefix}bmw_payout WHERE userid = '".$userid."' ";
		$result = $wpdb->get_var($sql);

		$old_unit = $result;
		$current_unit = $unit; 
		$total_unit = $old_unit + $current_unit; 
		$bonusArr = array();
		
		$bonusTakenArr = $this->getTakenBonus($userid); 
		if($bonusTakenArr){
		$bonusTaken = implode(",", $bonusTakenArr);
		} else{
			$bonusTaken ='';
		}
		$sql_bonus = "SELECT id, units, amount FROM {$wpdb->prefix}bmw_bonus
					  WHERE units <= '".$total_unit."'  AND 
							id NOT IN (".$bonusTaken.") AND 
							status = 0 ";	 
		
		$rs_bonus = $wpdb->get_results($sql_bonus); 
		$i=0;
		$bonusArr=array();
		
		if($rs_bonus && $wpdb->num_rows>0)
		{
			foreach($rs_bonus as $bonusrow)
			{
				$bonusArr[$i]['id'] = $bonusrow->id;
				$bonusArr[$i]['units'] = $bonusrow->units;
				$bonusArr[$i]['amount'] = $bonusrow->amount;
				$i++;
			}
		}
		return $bonusArr;
	}

	public function calculateTDS($userid,$comission,$bonus)
	{
		$payoutArr = get_option('bmw_payout_settings',true);
		$tdsRate = $payoutArr['bmw_tds'];
		
		$total = $comission + $bonus; 
		$tds = round($total*$tdsRate/100, 2);
			return $tds; 
	}

	public function getMembersByPayoutId($payoutId)
	{
		global $wpdb;
		$sql = "SELECT COUNT(id) AS totalMembers, SUM(commission_amount) AS commission,SUM(affiliate_commission) AS affiliate_commission,SUM(bonus_amount) AS bonus
				FROM {$wpdb->prefix}bmw_payout
				WHERE payout_id=".$payoutId."";
					
		$results = $wpdb->get_results($sql); 
		$num = $wpdb->num_rows;
		$total = 0;
		$returnArr =array(); 
		if($results && $num>0)
		{
			foreach($results as $row){
			$returnArr['members'] = $row->totalMembers; 
			$returnArr['commission'] = $row->commission;
			$returnArr['bonus'] = $row->bonus;
			$returnArr['affiliate_commission']=$row->affiliate_commission;
			$returnArr['totalAmount'] = $row->commission + $row->affiliate_commission+ $row->bonus; }	
		}
		return $returnArr; 
	}

/*==========================DIRECT GROUP DETAIL FUNCTION==================================*/
public function MyDirectGroupDetails($userKey)
	{ 
		global $wpdb;
		if(isset($userKey))
		{
			$sql = "SELECT user_id,user_key, parent_key,sponsor_key,leg,payment_status,
						DATE_FORMAT(`created_at`,'%d %b %Y') as creationDate,
						DATE_FORMAT(`paid_at`,'%Y%m%d') as paidDate
					FROM {$wpdb->prefix}bmw_users
					WHERE sponsor_key = '".$userKey."' ORDER BY created_at, id";
			$results = $wpdb->get_results($sql);
			$i=1;
			if($wpdb->num_rows > 0){

				foreach($results as $row){
					$data[$i]['id'] =  $i;
					$data[$i]['name'] =  $this->getUserNameById($row->user_id);
					$data[$i]['userKey'] = $row->user_key;
					$data[$i]['parentKey'] = $row->parent_key;
					$data[$i]['leg'] = $this->personalSalesLeg($userKey,$row->user_key);
					$data[$i]['creationDate'] = $row->creationDate;
					$data[$i]['paidDate'] = $row->paidDate;
					$i++;
				}
					
			}else{
				$data[$i]['id'] =  '';
				$data[$i]['name'] = __('No Consultant Found','bmw');
				$data[$i]['userKey'] = '';
				$data[$i]['parentKey'] = '';
				$data[$i]['leg'] = '';
				$data[$i]['creationDate'] = '';
				$data[$i]['paidDate'] = '';
				
			}
			//echo "<pre>";print_r($data); exit; 
			return $data;  
		}
	}
	
	/*----------------------------------------------------------------------------------
	Personal Sales Leg
	------------------------------------------------------------------------------------*/
	public function personalSalesLeg($pkey,$ukey)
	{
	global $wpdb;
		if(isset($pkey) && isset($ukey))
		{
			$sql = "SELECT id FROM {$wpdb->prefix}bmw_leftleg WHERE parent_key = '".$pkey."' AND user_key = '".$ukey."'";
			$results = $wpdb->get_var($sql);
			if($wpdb->num_rows > 0)
			{
				$leg = 'Left';
			}else{
				$leg = 'Right';
			}			
			return $leg; 
		}	

	}
	 
	 /*----------------------------------------------------------------------------------
	My Personal Sales Left Leg Total 
	------------------------------------------------------------------------------------*/
	public function MyDirectGroupTotal($userKey)
	{ 
		if(isset($userKey))
		{
			$total= array(); 
			
			$total['left'] =$this->MyDirectGroupTotalLeft($userKey); 
			$total['right'] =$this->MyDirectGroupTotalRight($userKey); 
			$total['total'] = $total['left'] + $total['right']; 
			return $total;
		}	
	}	
	
	/*----------------------------------------------------------------------------------
	My Personal Sales Left Leg Total 
	------------------------------------------------------------------------------------*/
	public function MyDirectGroupTotalLeft($userKey)
	{ 
		global $wpdb;
		if(isset($userKey))
		{
			/*Calculate Left Members*/
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_leftleg WHERE parent_key = '".$userKey."'";
			$results = $wpdb->get_results($sql);		
			$myLeft = 0;
			if($wpdb->num_rows > 0)
				{
					foreach ($results as $row) 
					{
						$ukey = $row->user_key;
						if(isset($ukey))
							{
							$sql_status = "SELECT id,sponsor_key FROM {$wpdb->prefix}bmw_users WHERE `user_key` ='".$ukey."'";	
							$row2 = $wpdb->get_row($sql_status); 
							if(($row2->sponsor_key)==$userKey)
							{
								$myLeft = $myLeft + 1; 							
							}																	
						}					
					}
				$myLeftTotal = $myLeft;
			}else{
				$myLeftTotal = 0;
			}
			return $myLeftTotal;
		}
	}
	
	/*----------------------------------------------------------------------------------
	My Personal Sales Right Leg Total 
	------------------------------------------------------------------------------------*/
	public function MyDirectGroupTotalRight($userKey)
	{
		global $wpdb;
		if(isset($userKey))
		{
		
			/*Calculate Right Members*/
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_rightleg WHERE parent_key = '".$userKey."'";
			$results = $wpdb->get_results($sql);				
			$myRight = 0;
			if($wpdb->num_rows > 0)
			{
				foreach ($results as $row) 
				{
					$ukey = $row->user_key;
					if(isset($ukey))
					{
						$sql_status = "SELECT id,sponsor_key FROM {$wpdb->prefix}bmw_users WHERE `user_key` ='".$ukey."'";	
						$row2 = $wpdb->get_row($sql_status);
						if(($row2->sponsor_key)==$userKey)
						{
							$myRight = $myRight + 1; 							
						}																	
					}					
				}
				$myRightTotal = $myRight;
			}else{
				$myRightTotal = 0;
			}
			return $myRightTotal;
		}
	}

/*==========================UNPAID CONSULTANT FUNCTIONS====================================*/
public function UnpaidConsultants($userKey)
	{
		if(isset($userKey))
		{
			$myLeft = $this->MyLeftLegMember($userKey); 
			$myRight = $this->MyRightLegMember($userKey);	
			
			if(count($myLeft)!=0 || count($myRight)!=0)
			{ 
				$consultant = array($myLeft, $myRight);
				return $consultant;
			
			}else{
				$data[0]['sno'] ='';
				$data[0]['name'] = __('No Consultant Found','bmw');
				$data[0]['userKey'] = '';
				$data[0]['referrer'] = '';
				$data[0]['payment_status']= '';
				$data[0]['leg']= '';
				$data[0]['creationDate']= '';
				$consultant = array($data);
				return $consultant;
			}	 
		}

	}
	/*----------------------------------------------------------------------------------
	My Left Leg Members
	------------------------------------------------------------------------------------*/	
	public function MyLeftLegMember($userKey)
	{ 
		global $wpdb;
		if(isset($userKey))
		{
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_leftleg WHERE parent_key = '".$userKey."' ORDER BY id";
			$results = $wpdb->get_results($sql);				
			$MyLeftArr = array();
			$i=1;
			if($wpdb->num_rows > 0)
			{
				foreach($results as $row)
				{
					$userKey = $row->user_key;
					$userDetail = $this->GetUnpaidUserInfoByKey($userKey);
					if(count($userDetail)!=0)   /*It checks that member is paid or not*/
					{
						$MyLeftArr[$i]['sno'] = $i;
						$MyLeftArr[$i]['name'] = $userDetail['name'];
						$MyLeftArr[$i]['userKey'] = $userDetail['key'];
						$MyLeftArr[$i]['referrer'] = $userDetail['referrer'];
						$MyLeftArr[$i]['payment_status']= $userDetail['payment_status'];
						$MyLeftArr[$i]['leg']= 'Left';
						$MyLeftArr[$i]['creationDate']= $userDetail['creationDate'];
						$MyLeftArr[$i]['dateFormat']= $userDetail['dateFormat'];
						$i++;
					}	
				}	
			} 
			return $MyLeftArr; 
		}
	}
	/*----------------------------------------------------------------------------------
	My Right Leg Members
	------------------------------------------------------------------------------------*/	
	public function MyRightLegMember($userKey)
	{
		global $wpdb;
		if(isset($userKey))
		{
		
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_rightleg WHERE parent_key = '".$userKey."' ORDER BY id";
			$results = $wpdb->get_results($sql);
			$MyRightArr = array();
			$i=1;
			if($wpdb->num_rows > 0)
			{
				foreach($results as $row)
				{
					$user_key = $row->user_key;
					$userDetail = $this->GetUnpaidUserInfoByKey($user_key);
					if(count($userDetail)!=0)   /*It checks that member is paid or not*/
					{
						$MyRightArr[$i]['sno'] = $i;
						$MyRightArr[$i]['name'] = $userDetail['name'];
						$MyRightArr[$i]['userKey'] = $userDetail['key'];
						$MyRightArr[$i]['referrer'] = $userDetail['referrer'];
						$MyRightArr[$i]['payment_status']= $userDetail['payment_status'];
						$MyRightArr[$i]['leg']= 'Right';
						$MyRightArr[$i]['creationDate']= $userDetail['creationDate'];
						$MyRightArr[$i]['dateFormat']= $userDetail['dateFormat'];
						$i++;
					}
				}
					
			}
			return $MyRightArr; 
		}
	}
	
	/*----------------------------------------------------------------------------------
	User Info from bmw user table 
	------------------------------------------------------------------------------------*/
	public function GetUnpaidUserInfoByKey($userKey)
	{
		global $wpdb;
		if(isset($userKey))
		{
			
			$sql = 	"SELECT user_id, user_key,sponsor_key, DATE_FORMAT(`created_at`,'%d %b %Y') as creationDate,
							DATE_FORMAT(`created_at`,'%Y%m%d') as dateFormat,payment_status 
						FROM  {$wpdb->prefix}bmw_users
						WHERE 	
							user_key ='".$userKey."' AND payment_status='0'";
			
			$row = $wpdb->get_row($sql);	
			$userDetail = array();
				if($wpdb->num_rows > 0)
				{
					
					$userDetail['key'] = $row->user_key;
					$userDetail['name'] = $this->getUserNameById($row->user_id);
					$userDetail['referrer'] = $this->getReferrerByKey($row->sponsor_key);
					$userDetail['creationDate'] = $row->creationDate;
					$userDetail['dateFormat'] = $row->dateFormat;
					$status = $row->payment_status;
					$userDetail['payment_status'] = $row->payment_status;
					
				} 
				return $userDetail; 
		}

	}
	/*----------------------------------------------------------------------------------
	My Left Leg Total Unpaid
	------------------------------------------------------------------------------------*/
	public function MyLeftLegMemberTotalUnpaid($userKey)
	{
		global $wpdb;
		if(isset($userKey))
		{
		
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_leftleg WHERE parent_key = '".$userKey."'";
			$results = $wpdb->get_results($sql); 			 
			$unpaid =0;
			if($wpdb->num_rows > 0)
			{
				foreach($results as $left_row)
				{
					$user_key = $left_row->user_key;
					if(isset($user_key))
					{
						$sql = "SELECT payment_status FROM {$wpdb->prefix}bmw_users WHERE 	
										`user_key` ='".$user_key."'";
						$status = $wpdb->get_var($sql);	
						if($status =='0')
						{
							$unpaid= $unpaid + 1; 							
						}																	
					}					
				}
				$myLeftUnpaid = $unpaid;
			}else{
				$myLeftUnpaid = 0;
			}
			return $myLeftUnpaid;
		}
	}
	
	/*----------------------------------------------------------------------------------
	My Right Leg Total Unpaid
	------------------------------------------------------------------------------------*/
	public function MyRightLegMemberTotalUnpaid($userKey)
	{
		global $wpdb;
		if(isset($userKey))
		{
			$sql = "SELECT user_key FROM {$wpdb->prefix}bmw_rightleg WHERE parent_key = '".$userKey."'";
			$results = $wpdb->get_results($sql);
				
			$unpaid =0;
			if($wpdb->num_rows > 0)
			{
				foreach($results as $right_row)
				{
					$user_key = $right_row->user_key;
					if(isset($user_key))
					{
						$sql = "SELECT payment_status FROM {$wpdb->prefix}bmw_users WHERE `user_key` ='".$user_key."'";	
						$status = $wpdb->get_var($sql);	
						if($status =='0')
						{
							$unpaid= $unpaid + 1; 							
						}																	
					}					
				}
				$myRightUnpaid = $unpaid;
			}else{
				$myRightUnpaid = 0;
			}
			return $myRightUnpaid;
		}
	}

/*==========================GENEALOGY FUNCTIONS================================*/
public function MyNetwork($userKey,$level)
	{

		$levelArr = array(); 
		$levelArr[0] = $this->LevelZero($userKey); 

		for($i=1,$j=0; $i<= $level; $i++,$j++)
		{ 
			$levelArr[$i] = $this->BuildLevelArr($levelArr[$j]);
		}		
		return $levelArr; 
	}

	/*----------------------------------------------------------------------------------
	Top of the network
	------------------------------------------------------------------------------------*/
	public function LevelZero($userKey)
	{ 
	    global $wpdb;
	    if(isset($userKey))
		{
			$sql = "SELECT user_id,user_key,parent_key,sponsor_key, DATE_FORMAT(`created_at`,'%d %M %Y') as creationDate, 
							payment_status, paid_at
					FROM {$wpdb->prefix}bmw_users 
					WHERE `user_key` = '".$userKey."'";
			$results = $wpdb->get_results($sql);

			$i=0;
			$data = array(); 
			
			if($wpdb->num_rows > 0)
			{
				foreach($results as $row)
				{	
					$data[$i]['name'] = $this->getUserNameById($row->user_id);
					$data[$i]['username']=$this->getUserNameByUserId($row->user_id);
					$data[$i]['leg']='';
					$Dashboard = new Bmw_Dashboard();
					$data[$i]['leftTotal']=$Dashboard->MyLeftLegMemberTotal($row->user_id);
					$data[$i]['rightTotal']=$Dashboard->MyRightLegMemberTotal($row->user_id);
					$data[$i]['userKey'] = $row->user_key;
					$data[$i]['parentKey'] =$row->parent_key;   
					$data[$i]['sponsorKey'] =$row->sponsor_key;   
					$data[$i]['payment_status'] = ($row->payment_status==1 || $row->payment_status==2)?'paid':'unpaid';
					$data[$i]['created'] = $row->creationDate;
					
					$i++;
				}	
				$newArr = array($data);  //Array of array
				return $newArr;
			}	
		}
	}

	/*----------------------------------------------------------------------------------
	Level others
	------------------------------------------------------------------------------------*/
	public function BuildLevelArr($levelArr)
	{
		global $wpdb; 
		
	    if(isset($levelArr) && count($levelArr)>0)
		{  
			$i=0;
			$data = array();
			foreach($levelArr as $details=>$rows)
			{ 
				foreach($rows as $row)
				{ 
					if(isset($row['userKey']) && $row['userKey']!='')
					{  
						$data[$i] = $this->getChildDetailByParent($row['userKey']); 

						$i++;
					}	
				}	
			} 
			return $data;
		}
	}

	public function getChildDetailByParent($key)
	{
		
		global $wpdb;
		if(isset($key))
		{ 
			$sql = 	"SELECT user_id,user_key,sponsor_key,leg,DATE_FORMAT(`created_at`,'%d %M %Y') as creationDate, 
							payment_status, paid_at
						FROM {$wpdb->prefix}bmw_users
						WHERE `parent_key` = '".$key."'
						ORDER BY leg desc";
			$results = 	$wpdb->get_results($sql);

 //echo'<pre>';print_r($key);die;	
			$i=0;
			$data = array();
			if($wpdb->num_rows ==2)
			{ 
				foreach($results as $row)
				{ 
					$data[$i]['name'] = $this->getUserNameById($row->user_id);
                    $data[$i]['username']=$this->getUserNameByUserId($row->user_id);

                    	$Dashboard = new Bmw_Dashboard();
                    $data[$i]['leftTotal']=$Dashboard->MyLeftLegMemberTotal($row->user_id);
                    $data[$i]['rightTotal']=$Dashboard->MyRightLegMemberTotal($row->user_id);
					$data[$i]['userKey'] = $row->user_key;
					$data[$i]['parentKey'] = $key;
					$data[$i]['sponsorKey'] = $row->sponsor_key;
					$data[$i]['payment_status'] = ($row->payment_status==1 || $row->payment_status==2)?'paid':'unpaid';
					$data[$i]['created'] = $row->creationDate;
					$data[$i]['leg'] = $row->leg;
					$i++;
				}			

			}else if($wpdb->num_rows ==1){	
				foreach($results as $row){
					$leg = $row->leg;
						
				if($leg==0)
				{	
					$data[0]['name'] = $this->getUserNameById($row->user_id);
                    $data[0]['username']=$this->getUserNameByUserId($row->user_id);
                    	$Dashboard = new Bmw_Dashboard();
                    $data[0]['leftTotal']=$Dashboard->MyLeftLegMemberTotal($row->user_id);
                    $data[0]['rightTotal']=$Dashboard->MyRightLegMemberTotal($row->user_id);
					$data[0]['userKey'] = $row->user_key;
					$data[0]['sponsorKey'] = $row->sponsor_key;
					$data[0]['parentKey'] = $key;
					$data[0]['payment_status'] = ($row->payment_status==1 || $row->payment_status==2)?'paid':'unpaid';
					$data[0]['created'] = $row->creationDate;
					$data[0]['leg'] = $row->leg;
					
					$data[1]['name'] ='<a href="'.$this->addMemberLink($key,'right').'">Add</a>';
					$data[1]['username']='';
					$data[1]['leftTotal']['total']='';
					$data[1]['rightTotal']['total']='';
					$data[1]['userKey'] = '';
					$data[1]['payment_status'] = 'unpaid';
					$data[1]['parentKey'] = $key;
					$data[1]['sponsorKey'] = '';
					$data[1]['created'] = '';
					$data[1]['leg'] = 1;
					
				} else { 
				
					$data[0]['name'] = '<a href="'.$this->addMemberLink($key,'left').'">Add</a>';
					$data[0]['username']='';
					$data[0]['leftTotal']['total']='';
					$data[0]['rightTotal']['total']='';
					$data[0]['userKey'] = '';
					$data[0]['parentKey'] = $key;
					$data[0]['sponsorKey'] = '';
					$data[0]['payment_status'] = 'unpaid';
					$data[0]['created'] = '';
					$data[0]['leg'] = 0;
					
					$data[1]['name'] =  $this->getUserNameById($row->user_id);
                    $data[1]['username']=$this->getUserNameByUserId($row->user_id);
                    	$Dashboard = new Bmw_Dashboard();
                    $data[1]['leftTotal']=$Dashboard->MyLeftLegMemberTotal($row->user_id);
                    $data[1]['rightTotal']=$Dashboard->MyRightLegMemberTotal($row->user_id);
					$data[1]['userKey'] = $row->user_key;
					$data[1]['parentKey'] = $key;
					$data[1]['sponsorKey'] = $row->sponsor_key;
					$data[1]['payment_status'] = ($row->payment_status==1 || $row->payment_status==2)?'paid':'unpaid';
					$data[1]['created'] = $row->creationDate;
					$data[1]['leg'] = $row->leg;
				}}
                                                                                                                                
			}else{ 

				
				$data[0]['name'] = '<a href="'.$this->addMemberLink($key,'left').'">Add</a>';
                $data[0]['username']='';
                $data[0]['leftTotal']['total']='';
				$data[0]['rightTotal']['total']='';
				$data[0]['userKey'] = '';
				$data[0]['parentKey'] = $key;
				$data[0]['sponsorKey'] ='';
				$data[0]['payment_status'] ='';
				$data[0]['created'] = '';
				$data[0]['leg'] = 0;	
				
				$data[1]['name'] = '<a href="'.$this->addMemberLink($key,'right').'">Add</a>';
                $data[1]['username']='';
                $data[1]['leftTotal']['total']='';
				$data[1]['rightTotal']['total']='';
				$data[1]['userKey'] = '';
				$data[1]['parentKey'] = $key;
				$data[1]['sponsorKey'] = '';
				$data[1]['payment_status'] = '';
				$data[1]['created'] = '';
				$data[1]['leg'] = 1;
	
			}
			return $data;
		}
	}

	/*end of the class*/

	public function addMemberLink( $parent, $leg)
	{
		if($leg =='right'){
			$leg = 1;
		}else{
			$leg = 0;
		}
			
		$reg_page_id = $this->bmw_get_the_post_id_by_shortcode('[bmw_registration]');
		$reg_page_link = '?page_id='.$reg_page_id.'&k='.$parent.'&l='.$leg; 
		
		return $reg_page_link;
	
	}


	public function leftmonthcount($month,$key)
	{ 
		global $wpdb;
		$sql = "SELECT count(*) as left_user FROM `{$wpdb->prefix}bmw_users`   WHERE user_key IN(SELECT user_key FROM `{$wpdb->prefix}bmw_leftleg` WHERE parent_key='$key')
			AND MONTH(`{$wpdb->prefix}bmw_users`.`created_at`)=$month";

		$left_count = $wpdb->get_var($sql);
		return $left_count;

	}

	public function rightmonthcount($month,$key)
	{
		global $wpdb;
		$sql = "SELECT count(*) as right_user FROM `{$wpdb->prefix}bmw_users`   WHERE user_key IN(SELECT user_key FROM `{$wpdb->prefix}bmw_rightleg` WHERE parent_key='$key')
			AND MONTH(`{$wpdb->prefix}bmw_users`.`created_at`)=$month";

		$right_count = $wpdb->get_var($sql);
		return $right_count;
	}

	public function getcommission($month,$user_id)
	{ 
		global $wpdb; 
		$sql = "select sum(commission_amount) as commission_amount from {$wpdb->prefix}bmw_payout where userid='$user_id' and MONTH(date)=$month";
		$comm_amount = (int)$wpdb->get_var($sql); 
		return $comm_amount;
	}

	public function getbonus($month,$user_id)
	{ 
		global $wpdb; 
		$sql = "select sum(bonus_amount) as bonus_amount from {$wpdb->prefix}bmw_payout where userid='$user_id' and MONTH(date)=$month";
		$bonus_amount = (int)$wpdb->get_var($sql); 
		return $bonus_amount;
	}

	public function getaffcomm($month,$user_id)
	{ 
		global $wpdb; 
		$sql = "select sum(affiliate_commission) as affiliate_commission from {$wpdb->prefix}bmw_payout where userid='$user_id' and MONTH(date)=$month";
		$aff_amount = (int)$wpdb->get_var($sql); 
		return $aff_amount;
	}

}